import React, { useState, useRef, useEffect } from "react";
import { MenuIcon, Clock, LogOut, User } from "lucide-react";
import { useAuth } from "../../auth/AuthContext";
import BranchSwitcher from "../../auth/BranchSwitcher";

// Dropdown kecil: nama user + tombol keluar. Self-contained lewat useAuth()
// supaya App.jsx tidak perlu diubah untuk meneruskan props auth ke sini.
function UserMenu() {
    const { user, role, signOut } = useAuth();
    const [isOpen, setIsOpen] = useState(false);
    const wrapperRef = useRef(null);

    useEffect(() => {
        const handleClickOutside = (e) => {
            if (wrapperRef.current && !wrapperRef.current.contains(e.target)) {
                setIsOpen(false);
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    const roleLabel = { owner: 'Owner', admin: 'Admin', kasir: 'Kasir' }[role] ?? role;

    return (
        <div className="relative" ref={wrapperRef}>
            <button
                onClick={() => setIsOpen(v => !v)}
                className="flex items-center gap-2 pl-1 pr-2 py-1 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full transition-colors"
            >
                <div className="w-8 h-8 rounded-full bg-accent-100 dark:bg-accent-500/15 text-accent-600 dark:text-accent-400 flex items-center justify-center shrink-0">
                    <User className="w-4 h-4" />
                </div>
                <div className="hidden md:block text-left leading-tight">
                    <p className="text-xs font-bold text-slate-700 dark:text-slate-200 truncate max-w-[120px]">{user?.name}</p>
                    <p className="text-[10px] text-slate-400 dark:text-slate-500">{roleLabel}</p>
                </div>
            </button>

            {isOpen && (
                <div className="absolute right-0 mt-2 w-56 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl shadow-xl z-50 p-2 animate-in fade-in zoom-in-95 duration-150">
                    <div className="px-3 py-2 border-b border-slate-100 dark:border-slate-800 mb-1">
                        <p className="text-sm font-bold text-slate-800 dark:text-slate-100 truncate">{user?.name}</p>
                        <p className="text-xs text-slate-400 dark:text-slate-500 truncate">{user?.email}</p>
                    </div>
                    <button
                        onClick={signOut}
                        className="w-full flex items-center gap-2 px-3 py-2.5 rounded-xl text-sm font-medium text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-500/10 transition-colors"
                    >
                        <LogOut className="w-4 h-4" />
                        Keluar
                    </button>
                </div>
            )}
        </div>
    );
}

export default function Header({
    currentShift,
    currentView,
    today,
    setIsSidebarOpen,
}) {
    return (
        <header className="bg-white dark:bg-slate-900 border-b border-slate-100 dark:border-slate-800 h-16 flex items-center justify-between px-4 z-20 shadow-[0_4px_20px_rgba(0,0,0,0.02)] shrink-0">
            <div className="flex items-center gap-3">
                <button className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg md:hidden text-slate-600 dark:text-slate-300 transition-colors" onClick={() => setIsSidebarOpen(true)}><MenuIcon className="w-6 h-6" /></button>
                <div><h2 className="font-heading font-black text-slate-900 dark:text-slate-50 text-xl tracking-tight capitalize">{currentView.replace('-', ' ')}</h2></div>
            </div>
            <div className="flex items-center gap-3">
                {currentShift && <span className="hidden md:inline-block bg-blue-50 dark:bg-blue-500/10 text-blue-600 dark:text-blue-400 px-3 py-1 rounded-full text-xs font-bold border border-blue-100 dark:border-blue-500/20"><Clock className="w-3 h-3 inline-block mr-1 mb-0.5" /> Dompet Aktif</span>}
                <div className="hidden lg:flex items-center bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 px-4 py-2 rounded-full text-[10px] md:text-xs font-bold border border-slate-200 dark:border-slate-700 whitespace-nowrap">{today}</div>
                <BranchSwitcher />
                <UserMenu />
            </div>
        </header>
    );
}
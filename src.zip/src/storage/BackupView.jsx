import { useState, useEffect, useRef } from 'react';
import {
  FileJson, Sheet, CloudUpload,
  Upload, FileUp, AlertTriangle, CheckCircle,
  Database, RefreshCw, X, ArrowLeft,
  Calendar, Info, Wifi, WifiOff, Clock,
} from 'lucide-react';
import { Capacitor } from '@capacitor/core';
import { Filesystem, Directory } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';
import { exportAllData, loadData, saveData } from '../storage/db';
import { ALL_KEYS, TRANSACTION_KEYS, APP_CONFIG_KEYS, DATE_FILTERABLE_KEYS } from '../storage/syncKeys';
import { getSupabaseClient, isSupabaseConfigured } from '../storage/syncClient';
import { runAutoSync, isSyncInFlight, isAutoSyncEnabled, setAutoSyncEnabled } from '../storage/realtimeSync';
import appVersion from '../version.json';

// ── Helpers ────────────────────────────────────────────────────────────────

async function writeAllToDexie(data, mode = 'merge') {
  for (const key of ALL_KEYS) {
    if (!(key in data)) continue;

    if (mode === 'replace') {
      await saveData(key, data[key]);
      continue;
    }

    const MISSING = '__DEXIE_MISSING__';
    const existing = await loadData(key, MISSING);

    if (existing === MISSING) {
      await saveData(key, data[key]);
      continue;
    }

    if (Array.isArray(existing) && Array.isArray(data[key])) {
      const merged = [...existing];
      for (const item of data[key]) {
        const alreadyExists = merged.find(e => String(e.id) === String(item.id));
        if (!alreadyExists) merged.push(item);
      }
      await saveData(key, merged);
      continue;
    }

    if (
      existing !== null && typeof existing === 'object' && !Array.isArray(existing) &&
      data[key] !== null && typeof data[key] === 'object' && !Array.isArray(data[key])
    ) {
      const merged = { ...data[key], ...existing };
      await saveData(key, merged);
      continue;
    }

    if (existing === null || existing === undefined) {
      await saveData(key, data[key]);
    }
  }
}

function filterByDateRange(data, startDate, endDate) {
  if (!startDate && !endDate) return data;
  const start = startDate ? new Date(startDate + 'T00:00:00') : null;
  const end = endDate ? new Date(endDate + 'T23:59:59') : null;
  const result = {};
  for (const key of ALL_KEYS) {
    if (!data[key]) continue;
    const dateField = DATE_FILTERABLE_KEYS[key];
    if (!dateField || !Array.isArray(data[key])) { result[key] = data[key]; continue; }
    result[key] = data[key].filter(item => {
      if (!item[dateField]) return false;
      const d = new Date(item[dateField]);
      if (start && d < start) return false;
      if (end && d > end) return false;
      return true;
    });
  }
  return result;
}

function calcStorageSize(allData) {
  const total = JSON.stringify(allData).length;
  if (total < 1024) return `${total} B`;
  if (total < 1048576) return `${(total / 1024).toFixed(1)} KB`;
  return `${(total / 1048576).toFixed(1)} MB`;
}

function calcRecordCount(allData) {
  let count = 0;
  for (const key of ['salesHistory', 'expenses', 'incomes', 'employees']) {
    if (Array.isArray(allData[key])) count += allData[key].length;
  }
  return count;
}

const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

const PHASE_LABEL = {
  transaction: 'Transaksi',
  config: 'Konfigurasi',
  live: 'Status Live',
};

// syncAllToSupabase dihapus — digantikan runAutoSync({ force: true })
// yang hanya mengirim data yang benar-benar berubah sejak sync terakhir.

async function restoreFromSupabase(mode = 'replace') {
  const supabase = await getSupabaseClient();
  if (!supabase) throw new Error('Konfigurasi Supabase belum ada di .env');

  const restored = {};

  for (const key of TRANSACTION_KEYS) {
    const { data: rows, error } = await supabase.from(key).select('payload');
    if (error) throw new Error(`Gagal restore [${key}]: ${error.message}`);
    restored[key] = (rows || []).map(r => r.payload);
  }

  const { data: configRows, error: configErr } = await supabase
    .from('app_config').select('key, value').in('key', APP_CONFIG_KEYS);
  if (configErr) throw new Error(`Gagal restore config: ${configErr.message}`);
  for (const row of configRows || []) restored[row.key] = row.value;

  await writeAllToDexie(restored, mode);
  return Object.keys(restored).length;
}

// ── DateRangeModal ─────────────────────────────────────────────────────────

function DateRangeModal({ onClose, onConfirm, exportType }) {
  const today = new Date().toISOString().slice(0, 10);
  const firstOfMonth = new Date(new Date().getFullYear(), new Date().getMonth(), 1)
    .toISOString().slice(0, 10);

  const [startDate, setStartDate] = useState(firstOfMonth);
  const [endDate, setEndDate] = useState(today);
  const [preset, setPreset] = useState('thisMonth');

  const PRESETS = [
    { id: 'today', label: 'Hari Ini', getRange: () => ({ s: today, e: today }) },
    {
      id: 'thisWeek', label: 'Minggu Ini', getRange: () => {
        const d = new Date(), day = d.getDay(), mon = new Date(d);
        mon.setDate(d.getDate() - (day === 0 ? 6 : day - 1));
        return { s: mon.toISOString().slice(0, 10), e: today };
      }
    },
    { id: 'thisMonth', label: 'Bulan Ini', getRange: () => ({ s: firstOfMonth, e: today }) },
    {
      id: 'lastMonth', label: 'Bulan Lalu', getRange: () => {
        const d = new Date();
        const first = new Date(d.getFullYear(), d.getMonth() - 1, 1);
        const last = new Date(d.getFullYear(), d.getMonth(), 0);
        return { s: first.toISOString().slice(0, 10), e: last.toISOString().slice(0, 10) };
      }
    },
    { id: 'allTime', label: 'Semua Data', getRange: () => ({ s: '', e: '' }) },
    { id: 'custom', label: 'Kustom', getRange: () => ({ s: startDate, e: endDate }) },
  ];

  function applyPreset(p) {
    setPreset(p.id);
    if (p.id !== 'custom') { const { s, e } = p.getRange(); setStartDate(s); setEndDate(e); }
  }

  const isAllTime = preset === 'allTime';
  const hasRange = !isAllTime && (startDate || endDate);
  const label = exportType === 'json' ? 'JSON' : 'Excel';

  return (
    <div className="fixed inset-0 z-[60] flex items-end justify-center bg-black/60 backdrop-blur-sm" onClick={onClose}>
      <div onClick={e => e.stopPropagation()} className="bg-white dark:bg-slate-900 w-full max-w-md rounded-t-3xl p-5 pb-8" style={{ animation: 'slideUp 0.25s ease' }}>
        <div className="w-10 h-1 bg-slate-200 dark:bg-slate-700 rounded-full mx-auto mb-5" />
        <div className="flex items-center gap-3 mb-5">
          <div className="w-10 h-10 rounded-xl bg-accent-50 dark:bg-accent-500/10 flex items-center justify-center text-xl">
            {exportType === 'json' ? '📦' : '📊'}
          </div>
          <div>
            <p className="font-black text-slate-900 dark:text-slate-100 text-base">Export {label} — Pilih Rentang</p>
            <p className="text-xs text-slate-400 dark:text-slate-500">Filter berdasarkan tanggal transaksi</p>
          </div>
        </div>

        <div className="flex flex-wrap gap-2 mb-4">
          {PRESETS.map(p => (
            <button key={p.id} onClick={() => applyPreset(p)}
              className={`px-3 py-1.5 rounded-full text-xs font-bold border-2 transition-all
                ${preset === p.id ? 'border-accent-500 bg-accent-500 text-white' : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:border-accent-300 dark:hover:border-accent-500/50'}`}
            >{p.label}</button>
          ))}
        </div>

        {preset === 'custom' && (
          <div className="grid grid-cols-2 gap-3 mb-4">
            {[['Dari Tanggal', startDate, setStartDate], ['Sampai Tanggal', endDate, setEndDate]].map(([lbl, val, set]) => (
              <div key={lbl}>
                <p className="text-xs font-bold text-slate-400 dark:text-slate-500 mb-1.5 uppercase tracking-wider">{lbl}</p>
                <input type="date" value={val} onChange={e => set(e.target.value)}
                  className="w-full border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-700 dark:text-slate-200 rounded-xl px-3 py-2.5 text-sm font-semibold outline-none focus:border-accent-500 dark:focus:border-accent-500 transition-colors" />
              </div>
            ))}
          </div>
        )}

        {hasRange && (
          <div className="bg-accent-50 dark:bg-accent-500/10 border border-accent-200 dark:border-accent-500/30 rounded-xl px-4 py-3 mb-4 flex items-center gap-2">
            <Calendar className="w-4 h-4 text-accent-500 dark:text-accent-400 shrink-0" />
            <p className="text-xs text-accent-700 dark:text-accent-300 font-semibold">{startDate || '∞'} — {endDate || '∞'}</p>
          </div>
        )}
        {isAllTime && (
          <div className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-3 mb-4 flex items-center gap-2">
            <Info className="w-4 h-4 text-slate-400 shrink-0" />
            <p className="text-xs text-slate-500 dark:text-slate-400 font-semibold">Semua data tanpa filter tanggal</p>
          </div>
        )}

        <button onClick={() => onConfirm(isAllTime ? '' : startDate, isAllTime ? '' : endDate)}
          className="w-full py-4 rounded-xl font-black text-sm bg-accent-600 dark:bg-accent-500 hover:bg-accent-700 dark:hover:bg-accent-600 text-white shadow-lg shadow-accent-200 dark:shadow-none transition-all">
          Download {label}
        </button>
      </div>
    </div>
  );
}

// ── ImportModal ────────────────────────────────────────────────────────────

function ImportModal({ type, onClose, onConfirm }) {
  const inputRef = useRef(null);
  const [dragOver, setDragOver] = useState(false);
  const [file, setFile] = useState(null);
  const [mode, setMode] = useState('merge');
  const [replaceConfirm, setReplaceConfirm] = useState('');

  const label = type === 'json' ? 'JSON' : 'Excel (.xlsx)';
  const accept = type === 'json' ? '.json,application/json' : '.xlsx,.xls';
  const fmtBytes = b => b < 1024 ? `${b} B` : b < 1048576 ? `${(b / 1024).toFixed(1)} KB` : `${(b / 1048576).toFixed(1)} MB`;

  const canSubmit = file && (mode === 'merge' || replaceConfirm.trim().toUpperCase() === 'TIMPA');

  function handleModeChange(val) {
    setMode(val);
    setReplaceConfirm('');
  }

  return (
    <div className="fixed inset-0 z-[60] flex items-end justify-center bg-black/60 backdrop-blur-sm" onClick={onClose}>
      <div onClick={e => e.stopPropagation()} className="bg-white dark:bg-slate-900 w-full max-w-md rounded-t-3xl p-5 pb-8" style={{ animation: 'slideUp 0.25s ease' }}>
        <div className="w-10 h-1 bg-slate-200 dark:bg-slate-700 rounded-full mx-auto mb-5" />

        <div className="flex items-center gap-3 mb-5">
          <div className="w-10 h-10 rounded-xl bg-accent-50 dark:bg-accent-500/10 flex items-center justify-center">
            <FileUp className="w-5 h-5 text-accent-500 dark:text-accent-400" />
          </div>
          <div>
            <p className="font-black text-slate-900 dark:text-slate-100 text-base">Import dari {label}</p>
            <p className="text-xs text-slate-400 dark:text-slate-500">Data lokal aman — mode default: Gabungkan</p>
          </div>
        </div>

        <div
          onDragOver={e => { e.preventDefault(); setDragOver(true); }}
          onDragLeave={() => setDragOver(false)}
          onDrop={e => { e.preventDefault(); setDragOver(false); setFile(e.dataTransfer.files[0]); }}
          onClick={() => !file && inputRef.current?.click()}
          className={`border-2 border-dashed rounded-2xl p-6 text-center mb-4 cursor-pointer transition-all
            ${dragOver ? 'border-accent-400 bg-accent-50 dark:bg-accent-500/10' : file ? 'border-green-400 bg-green-50 dark:bg-green-500/10' : 'border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 hover:border-accent-300 dark:hover:border-accent-500/50'}`}
        >
          {file ? (
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-green-100 dark:bg-green-500/15 flex items-center justify-center shrink-0">
                <CheckCircle className="w-5 h-5 text-green-600 dark:text-green-400" />
              </div>
              <div className="text-left flex-1 min-w-0">
                <p className="font-bold text-sm text-slate-800 dark:text-slate-100 truncate">{file.name}</p>
                <p className="text-xs text-slate-400 dark:text-slate-500">{fmtBytes(file.size)}</p>
              </div>
              <button onClick={e => { e.stopPropagation(); setFile(null); }} className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 p-1">
                <X className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <>
              <Upload className="w-8 h-8 text-slate-300 dark:text-slate-600 mx-auto mb-2" />
              <p className="font-semibold text-sm text-slate-600 dark:text-slate-300">{dragOver ? 'Lepaskan file di sini' : 'Ketuk untuk pilih file'}</p>
              <p className="text-xs text-slate-400 dark:text-slate-500 mt-1">atau seret & lepas file {label}</p>
            </>
          )}
        </div>

        <input ref={inputRef} type="file" accept={accept} className="hidden" onChange={e => setFile(e.target.files[0])} />

        <p className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-2">Mode Import</p>
        <div className="grid grid-cols-2 gap-2 mb-4">
          <button onClick={() => handleModeChange('merge')}
            className={`p-3 rounded-xl border-2 text-left transition-all ${mode === 'merge' ? 'border-accent-500 bg-accent-50 dark:bg-accent-500/10' : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:border-slate-300 dark:hover:border-slate-600'}`}
          >
            <p className="text-base mb-1">🔗</p>
            <p className={`font-bold text-xs ${mode === 'merge' ? 'text-accent-600 dark:text-accent-400' : 'text-slate-700 dark:text-slate-300'}`}>Gabungkan</p>
            <p className="text-xs text-slate-400 dark:text-slate-500">Tambah ke data ada</p>
            {mode === 'merge' && <p className="text-xs text-accent-500 dark:text-accent-400 font-bold mt-1">✓ Aman — direkomendasikan</p>}
          </button>
          <button onClick={() => handleModeChange('replace')}
            className={`p-3 rounded-xl border-2 text-left transition-all ${mode === 'replace' ? 'border-red-400 bg-accent-50 dark:bg-accent-500/10' : 'border-slate-100 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 hover:border-slate-300 dark:hover:border-slate-600'}`}
          >
            <p className="text-base mb-1">🔄</p>
            <p className={`font-bold text-xs ${mode === 'replace' ? 'text-accent-600 dark:text-accent-400' : 'text-slate-400 dark:text-slate-500'}`}>Timpa Semua</p>
            <p className="text-xs text-slate-400 dark:text-slate-500">Hapus data lama</p>
          </button>
        </div>

        {mode === 'replace' && (
          <div className="bg-accent-50 dark:bg-accent-500/10 border-2 border-red-200 dark:border-red-500/30 rounded-xl p-4 mb-4 space-y-3">
            <div className="flex gap-2 items-start">
              <AlertTriangle className="w-4 h-4 text-accent-500 dark:text-accent-400 shrink-0 mt-0.5" />
              <p className="text-xs text-accent-700 dark:text-accent-300 leading-relaxed">
                <strong>Peringatan!</strong> Mode ini akan menghapus SELURUH data lokal dan menggantinya dengan isi file import.
                Tindakan ini tidak bisa dibatalkan.
              </p>
            </div>
            <div>
              <p className="text-xs font-bold text-accent-500 dark:text-accent-400 mb-1.5">
                Ketik <span className="bg-accent-100 dark:bg-accent-500/20 px-1.5 py-0.5 rounded font-mono">TIMPA</span> untuk konfirmasi:
              </p>
              <input
                type="text"
                value={replaceConfirm}
                onChange={e => setReplaceConfirm(e.target.value)}
                placeholder="Ketik TIMPA di sini..."
                className="w-full border border-red-200 dark:border-red-500/30 bg-white dark:bg-slate-950 text-slate-700 dark:text-slate-200 rounded-xl px-3 py-2.5 text-sm font-mono outline-none focus:border-red-400 dark:focus:border-red-400 transition-colors"
                autoComplete="off"
              />
            </div>
          </div>
        )}

        <button onClick={() => canSubmit && onConfirm(file, mode)} disabled={!canSubmit}
          className={`w-full py-4 rounded-xl font-black text-sm transition-all
            ${canSubmit
              ? mode === 'replace'
                ? 'bg-accent-500 dark:bg-accent-600 hover:bg-accent-600 dark:hover:bg-accent-500 text-white shadow-lg shadow-red-200 dark:shadow-none'
                : 'bg-accent-600 dark:bg-accent-500 hover:bg-accent-700 dark:hover:bg-accent-600 text-white shadow-lg shadow-accent-200 dark:shadow-none'
              : 'bg-slate-100 dark:bg-slate-800 text-slate-400 dark:text-slate-500 cursor-not-allowed'}`}
        >
          {file ? `Import ${label}` : 'Pilih file terlebih dahulu'}
        </button>
      </div>
    </div>
  );
}

// ── ActionItem ─────────────────────────────────────────────────────────────

function ActionItem({ icon: Icon, label, sublabel, onClick, loading, done, iconBgClass, iconColorClass, badge }) {
  return (
    <button onClick={loading || done ? undefined : onClick}
      className={`w-full flex items-center gap-4 p-4 rounded-2xl border-2 text-left transition-all
        ${done ? 'border-green-200 dark:border-green-500/40 bg-green-50 dark:bg-green-500/10' : loading ? 'border-accent-200 dark:border-accent-500/40 bg-accent-50 dark:bg-accent-500/10' : 'border-slate-100 dark:border-slate-700 bg-white dark:bg-slate-800 hover:border-accent-200 dark:hover:border-accent-500/50 hover:bg-accent-50 dark:hover:bg-accent-500/10'}`}
    >
      <div className={`w-12 h-12 rounded-xl flex items-center justify-center shrink-0 ${done ? 'bg-green-100 dark:bg-green-500/15' : iconBgClass}`}>
        {loading ? <RefreshCw className="w-5 h-5 text-accent-500 animate-spin" />
          : done ? <CheckCircle className="w-5 h-5 text-green-600 dark:text-green-400" />
            : <Icon className={`w-5 h-5 ${iconColorClass}`} />}
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <p className="font-bold text-sm text-slate-800 dark:text-slate-100">{label}</p>
          {badge && <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-accent-100 dark:bg-accent-500/20 text-accent-600 dark:text-accent-400">{badge}</span>}
        </div>
        <p className="text-xs mt-0.5">
          {loading ? <span className="text-accent-500 font-semibold">Memproses...</span>
            : done ? <span className="text-green-600 dark:text-green-400 font-semibold">Selesai</span>
              : <span className="text-slate-400 dark:text-slate-500">{sublabel}</span>}
        </p>
      </div>
      {!loading && !done && <span className="text-slate-300 dark:text-slate-600 text-xl font-bold">›</span>}
    </button>
  );
}

// ── SyncProgressBar ────────────────────────────────────────────────────────
// Nampilin progress backup manual secara real-time: key/tabel ke berapa dari
// berapa total, plus detail record di dalam tabel yang lagi diproses
// (mis. "salesHistory: 45/120"). Kalau totalInKey = 0 (belum ada info detail
// item, atau key-nya config/live-state yang cuma 1 unit), progress bar tetap
// nunjukin posisi key secara keseluruhan.
function SyncProgressBar({ progress }) {
  if (!progress) return null;

  const { keyIndex, totalKeys, key, phase, doneInKey, totalInKey, sentCount, failedCount } = progress;

  const keyPct = totalKeys > 0 ? Math.min(100, Math.round(((keyIndex - 1) / totalKeys) * 100)) : 0;
  const itemPct = totalInKey > 0 ? Math.round((doneInKey / totalInKey) * 100) : (doneInKey > 0 ? 100 : 0);
  // Progress keseluruhan: posisi key + kontribusi progress di dalam key itu.
  const overallPct = totalKeys > 0
    ? Math.min(100, Math.round((((keyIndex - 1) + (totalInKey > 0 ? doneInKey / totalInKey : 0)) / totalKeys) * 100))
    : 0;

  return (
    <div className="bg-indigo-50 dark:bg-indigo-500/10 border-2 border-indigo-200 dark:border-indigo-500/30 rounded-xl p-4 space-y-2.5">
      <div className="flex items-center justify-between">
        <span className="text-xs font-bold text-indigo-700 dark:text-indigo-300">
          {key ? `${PHASE_LABEL[phase] || ''} — ${key}` : 'Menyiapkan sync...'}
        </span>
        <span className="text-xs font-bold text-indigo-500 dark:text-indigo-400">{overallPct}%</span>
      </div>

      {/* Progress keseluruhan (semua tabel/key) */}
      <div className="h-2 bg-indigo-100 dark:bg-indigo-500/20 rounded-full overflow-hidden">
        <div className="h-full bg-indigo-500 rounded-full transition-all duration-200" style={{ width: `${overallPct}%` }} />
      </div>

      <div className="flex items-center justify-between text-xs text-indigo-400 dark:text-indigo-400/70">
        <span>Tabel {Math.min(keyIndex, totalKeys)} / {totalKeys}</span>
        {totalInKey > 0 && <span>{doneInKey} / {totalInKey} record</span>}
      </div>

      {/* Progress detail dalam key yang sedang jalan (relevan untuk tabel besar) */}
      {totalInKey > 0 && (
        <div className="h-1.5 bg-indigo-100 dark:bg-indigo-500/20 rounded-full overflow-hidden">
          <div className="h-full bg-indigo-400 rounded-full transition-all duration-200" style={{ width: `${itemPct}%` }} />
        </div>
      )}

      <div className="flex items-center gap-3 text-[11px] text-indigo-500 dark:text-indigo-400 pt-0.5">
        <span>✓ {sentCount} terkirim</span>
        {failedCount > 0 && <span className="text-amber-600 dark:text-amber-400">⚠ {failedCount} gagal</span>}
      </div>
    </div>
  );
}

// ── FailedSyncList ─────────────────────────────────────────────────────────
// Nampilin rincian record yang gagal push ke Supabase setelah sync manual
// selesai — tabel, id, dan pesan error asli dari Supabase/network — biar
// gak perlu buka console buat tau record mana yang bermasalah & kenapa.
// Tetap kelihatan sampai sync berikutnya dijalankan (lihat lastFailedItems
// di BackupView, beda dari syncProgress yang di-reset begitu sync selesai).
function FailedSyncList({ items }) {
  const [copied, setCopied] = useState(false);
  if (!items || items.length === 0) return null;

  const handleCopy = async () => {
    const text = items.map(i => `${i.tableKey} / ${i.id} — ${i.message}`).join('\n');
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (_) { /* clipboard gak tersedia, diamkan */ }
  };

  return (
    <div className="bg-amber-50 dark:bg-amber-500/10 border-2 border-amber-200 dark:border-amber-500/30 rounded-xl p-4 space-y-2.5">
      <div className="flex items-center justify-between">
        <span className="text-xs font-bold text-amber-700 dark:text-amber-300 flex items-center gap-1.5">
          <AlertTriangle className="w-3.5 h-3.5" /> {items.length} record gagal tersinkron
        </span>
        <button
          type="button"
          onClick={handleCopy}
          className="text-[10px] font-bold text-amber-600 dark:text-amber-400 border border-amber-300 dark:border-amber-500/40 rounded-lg px-2 py-1 hover:bg-amber-100 dark:hover:bg-amber-500/20 transition-colors"
        >
          {copied ? 'Tersalin ✓' : 'Salin Daftar'}
        </button>
      </div>
      <div className="space-y-1.5 max-h-[200px] overflow-y-auto custom-scrollbar">
        {items.map((item, idx) => (
          <div key={`${item.tableKey}-${item.id}-${idx}`} className="bg-white dark:bg-slate-900 rounded-lg px-3 py-2 border border-amber-100 dark:border-amber-500/20">
            <p className="text-[11px] font-mono font-bold text-slate-700 dark:text-slate-200">{item.tableKey} / {item.id}</p>
            <p className="text-[10px] text-amber-600 dark:text-amber-400 mt-0.5 break-words">{item.message}</p>
          </div>
        ))}
      </div>
      <p className="text-[10px] text-amber-600 dark:text-amber-400/80">
        Record ini otomatis dicoba lagi di sync berikutnya. Kalau terus gagal berulang kali, kemungkinan ada masalah di data record itu sendiri (bukan cuma koneksi).
      </p>
    </div>
  );
}

// ── BackupView ─────────────────────────────────────────────────────────────

const BackupView = ({ onBack }) => {
  const [loadingState, setLoadingState] = useState({});
  const [doneState, setDoneState] = useState({});
  const [toast, setToast] = useState(null);
  const [importModal, setImportModal] = useState(null);
  const [dateRangeModal, setDateRangeModal] = useState(null);
  const [isSyncing, setIsSyncing] = useState(false);
  const [isRestoring, setIsRestoring] = useState(false);
  const [syncProgress, setSyncProgress] = useState(null); // { keyIndex, totalKeys, key, phase, doneInKey, totalInKey, sentCount, failedCount, failedItems }
  // Beda dari syncProgress (yang di-null-in begitu sync selesai): ini SENGAJA
  // dipertahankan setelah sync kelar, biar user tetap bisa lihat record mana
  // yang gagal push tanpa harus buka console. Direset tiap kali sync baru dimulai.
  const [lastFailedItems, setLastFailedItems] = useState([]);
  const [storageSize, setStorageSize] = useState('Menghitung...');
  const [recordCount, setRecordCount] = useState('...');

  const supabaseReady = isSupabaseConfigured();
  const lastBackup = localStorage.getItem('mamam_last_backup') || 'Belum pernah';
  const [lastSyncTime, setLastSyncTime] = useState(() => {
    const raw = localStorage.getItem('mamam_last_supabase_sync');
    return raw ? new Date(raw).toLocaleString('id-ID') : null;
  });

  // Toggle auto-sync berkala. Jalannya sekarang di App.jsx level (global,
  // gak peduli lagi buka layar apa, plus flush pas app di-background/dibuka
  // lagi) — bukan lagi cek jam 21:00 di dalam layar ini doang. Flag-nya
  // disatuin sama yang dicek langsung sama runAutoSync() sendiri
  // (isAutoSyncEnabled/setAutoSyncEnabled di realtimeSync.js), biar cuma
  // ada SATU sumber kebenaran — gak ada 2 toggle beda localStorage key yang
  // gampang ketuker/gak sinkron satu sama lain.
  const [dailySyncOn, setDailySyncOn] = useState(() => isAutoSyncEnabled());

  function handleToggleDailySync() {
    const next = !dailySyncOn;
    setAutoSyncEnabled(next);
    setDailySyncOn(next);
  }

  // Baca timestamp sync terbaru dari localStorage dan update state
  const refreshSyncTime = useRef(() => {
    const raw = localStorage.getItem('mamam_last_supabase_sync');
    if (raw) setLastSyncTime(new Date(raw).toLocaleString('id-ID'));
  });

  useEffect(() => {
    exportAllData().then(allData => {
      setStorageSize(calcStorageSize(allData));
      setRecordCount(calcRecordCount(allData));
    });
  }, []);

  // Listener: update lastSyncTime kapanpun ada sync dari manapun — termasuk
  // dari auto-sync berkala & flush background/foreground yang jalan di App.jsx.
  useEffect(() => {
    const handler = () => refreshSyncTime.current();

    // storage event: fired saat localStorage diubah dari tab/konteks lain
    window.addEventListener('storage', (e) => {
      if (e.key === 'mamam_last_supabase_sync') handler();
    });

    // CustomEvent: fired dari realtimeSync saat sync selesai di tab yang sama
    window.addEventListener('mamam_sync_updated', handler);

    return () => {
      window.removeEventListener('storage', handler);
      window.removeEventListener('mamam_sync_updated', handler);
    };
  }, []);

  function showToast(msg, type = 'success') {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3500);
  }

  function startAction(key, delay, successMsg, action) {
    if (loadingState[key] || doneState[key]) return;
    setLoadingState(s => ({ ...s, [key]: true }));
    setTimeout(async () => {
      try {
        await action?.();
        setDoneState(s => ({ ...s, [key]: true }));
        showToast(successMsg);
        if (['exportJson', 'exportExcel'].includes(key)) {
          localStorage.setItem('mamam_last_backup', new Date().toLocaleString('id-ID'));
        }
        setTimeout(() => setDoneState(s => ({ ...s, [key]: false })), 3000);
      } catch (err) {
        showToast('Gagal: ' + err.message, 'error');
      } finally {
        setLoadingState(s => ({ ...s, [key]: false }));
      }
    }, delay);
  }

  function handleExportJsonWithRange(startDate, endDate) {
    setDateRangeModal(null);
    const tag = startDate && endDate ? `${startDate}_${endDate}` : 'semua';
    startAction('exportJson', 300,
      Capacitor.isNativePlatform() ? 'Membuka menu simpan...' : 'File JSON berhasil diunduh!',
      async () => {
        const raw = await exportAllData();
        const data = filterByDateRange(raw, startDate, endDate);
        const jsonStr = JSON.stringify(data, null, 2);
        const filename = `mamam-ayam-backup-data-${tag}.json`;

        if (Capacitor.isNativePlatform()) {
          const b64 = btoa(encodeURIComponent(jsonStr).replace(/%([0-9A-F]{2})/g, (_, p1) => String.fromCharCode(parseInt(p1, 16))));
          const r = await Filesystem.writeFile({ path: filename, data: b64, directory: Directory.Cache });
          await Share.share({ title: filename, url: r.uri, dialogTitle: 'Simpan / Bagikan Backup JSON' });
        } else {
          const url = URL.createObjectURL(new Blob([jsonStr], { type: 'application/json' }));
          Object.assign(document.createElement('a'), { href: url, download: filename }).click();
          URL.revokeObjectURL(url);
        }
      }
    );
  }

  function handleExportExcelWithRange(startDate, endDate) {
    setDateRangeModal(null);
    const tag = startDate && endDate ? `${startDate}_${endDate}` : 'semua';
    startAction('exportExcel', 400,
      Capacitor.isNativePlatform() ? 'Membuka menu simpan...' : 'File Excel berhasil diunduh!',
      async () => {
        const XLSX = await import('https://cdn.sheetjs.com/xlsx-0.20.1/package/xlsx.mjs');
        const raw = await exportAllData();
        const data = filterByDateRange(raw, startDate, endDate);
        const wb = XLSX.utils.book_new();
        const sheets = {
          salesHistory: 'Riwayat Penjualan', expenses: 'Pengeluaran',
          incomes: 'Pemasukan', employees: 'Karyawan',
          employeeDailyRecords: 'Absensi', shiftHistory: 'Riwayat Shift', customers: 'Pelanggan',
          cashTransfers: 'Setoran Kurir',
        };
        for (const [key, name] of Object.entries(sheets)) {
          if (data[key]?.length) XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(data[key]), name);
        }
        const filename = `mamam-ayam-laporan-excel-${tag}.xlsx`;
        if (Capacitor.isNativePlatform()) {
          const b64 = XLSX.write(wb, { type: 'base64', bookType: 'xlsx' });
          const r = await Filesystem.writeFile({ path: filename, data: b64, directory: Directory.Cache });
          await Share.share({ title: filename, url: r.uri, dialogTitle: 'Simpan / Bagikan Laporan Excel' });
        } else {
          XLSX.writeFile(wb, filename);
        }
      }
    );
  }

  function handleImportConfirm(file, mode) {
    setImportModal(null);
    startAction('importJson', 200, 'Data berhasil diimpor! Muat ulang aplikasi.', async () => {
      const parsed = JSON.parse(await file.text());
      await writeAllToDexie(parsed, mode);
      setTimeout(() => window.location.reload(), 1500);
    });
  }

  async function handleManualSync() {
    if (!supabaseReady) { showToast('Supabase belum dikonfigurasi di .env', 'error'); return; }
    if (isSyncInFlight()) { showToast('Sync sedang berjalan, tunggu sebentar...', 'error'); return; }
    setIsSyncing(true);
    setLastFailedItems([]); // reset daftar gagal dari run sebelumnya
    setSyncProgress({ keyIndex: 0, totalKeys: 1, key: '', phase: '', doneInKey: 0, totalInKey: 0, sentCount: 0, failedCount: 0, failedItems: [] });
    try {
      // Tiap item sekarang punya timeout 15 detik (lihat PUSH_TIMEOUT_MS di
      // realtimeSync.js), dan dikirim per-batch paralel (lihat AUTO_SYNC_BATCH_SIZE),
      // jadi proses ini jauh lebih cepat dan gak akan pernah "muter" tanpa
      // batas kayak sebelumnya.
      const { sent, failed, failedItems } = await runAutoSync({ force: true, onProgress: setSyncProgress });
      refreshSyncTime.current();
      setLastFailedItems(failedItems || []);
      if (failed > 0) {
        showToast(`${sent} terkirim, ${failed} gagal (timeout/koneksi) — otomatis dicoba lagi nanti`, 'error');
      } else {
        showToast(sent > 0 ? `Sync selesai — ${sent} perubahan dikirim` : 'Semua data sudah tersinkron ✓');
      }
    } catch (err) {
      showToast('Gagal: ' + err.message, 'error');
    } finally {
      setIsSyncing(false);
      setSyncProgress(null);
    }
  }

  async function handleRestoreFromSupabase() {
    if (!supabaseReady) { showToast('Supabase belum dikonfigurasi di .env', 'error'); return; }
    if (!window.confirm('Restore semua data dari Supabase?\nData lokal akan ditimpa sepenuhnya.')) return;
    setIsRestoring(true);
    try {
      const count = await restoreFromSupabase('replace');
      showToast(`Restore selesai — ${count} key dipulihkan`);
      setTimeout(() => window.location.reload(), 1500);
    } catch (err) {
      showToast('Gagal: ' + err.message, 'error');
    } finally {
      setIsRestoring(false);
    }
  }

  const STATUS_ROWS = [
    { label: 'Versi aplikasi', value: `v${appVersion.version} (${appVersion.updatedAt})` },
    { label: 'Backup local terakhir', value: lastBackup },
    { label: 'Sync cloud terakhir', value: lastSyncTime || 'Belum pernah' },
    { label: 'Total record', value: `±${recordCount} data` },
    { label: 'Ukuran tersimpan', value: storageSize },
  ];

  return (
    <div className="flex flex-col h-full bg-slate-50 dark:bg-slate-950 overflow-y-auto">

      {toast && (
        <div className={`fixed top-5 left-1/2 -translate-x-1/2 z-[60] px-5 py-3 rounded-2xl text-white text-sm font-bold shadow-xl whitespace-nowrap
          ${toast.type === 'error' ? 'bg-accent-500' : 'bg-green-500'}`} style={{ animation: 'fadeInDown 0.2s ease' }}>
          {toast.msg}
        </div>
      )}

      {importModal && <ImportModal type={importModal} onClose={() => setImportModal(null)} onConfirm={handleImportConfirm} />}
      {dateRangeModal && (
        <DateRangeModal exportType={dateRangeModal} onClose={() => setDateRangeModal(null)}
          onConfirm={dateRangeModal === 'json' ? handleExportJsonWithRange : handleExportExcelWithRange} />
      )}

      {/* Header */}
      <div className="bg-white dark:bg-slate-900 border-b border-slate-100 dark:border-slate-800 px-4 py-4 flex items-center gap-3 shrink-0">
        {onBack && (
          <button onClick={onBack} className="p-1 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors">
            <ArrowLeft className="w-5 h-5 text-slate-600 dark:text-slate-400" />
          </button>
        )}
        <h2 className="font-black text-xl text-slate-800 dark:text-slate-100 flex items-center gap-2 flex-1">
          <Database className="w-6 h-6 text-accent-500" /> Backup & Restore
        </h2>
        <div className={`flex items-center gap-1.5 rounded-full px-3 py-1 border text-xs font-bold
          ${supabaseReady ? 'bg-emerald-50 dark:bg-emerald-500/10 border-emerald-200 dark:border-emerald-500/30 text-emerald-600 dark:text-emerald-400' : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-400 dark:text-slate-500'}`}>
          {supabaseReady ? <Wifi className="w-3.5 h-3.5" /> : <WifiOff className="w-3.5 h-3.5" />}
          {supabaseReady ? 'Cloud' : 'Offline'}
        </div>
      </div>

      <div className="p-4 space-y-4">

        {/* Status */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-100 dark:border-slate-800 shadow-sm">
          <div className="flex items-center justify-between mb-3">
            <p className="font-bold text-sm text-slate-700 dark:text-slate-200">Status Penyimpanan</p>
            <span className="text-xs font-bold text-green-600 dark:text-green-400 bg-green-50 dark:bg-green-500/10 border border-green-200 dark:border-green-500/30 rounded-full px-3 py-0.5">● Aktif</span>
          </div>
          <div className="space-y-2">
            {STATUS_ROWS.map(({ label, value }) => (
              <div key={label} className="flex justify-between items-center py-1.5 border-b border-slate-50 dark:border-slate-800 last:border-0">
                <span className="text-xs text-slate-400 dark:text-slate-500">{label}</span>
                <span className="text-xs font-bold text-slate-700 dark:text-slate-200">{value}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Cloud Sync */}
        <div>
          <p className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-2 px-1">Cloud Sync Realtime — Supabase</p>
          <div className="bg-white dark:bg-slate-900 rounded-2xl border-2 border-slate-100 dark:border-slate-800 p-4 space-y-4">

            {!supabaseReady && (
              <div className="flex gap-2 items-start bg-amber-50 dark:bg-amber-500/10 border border-amber-200 dark:border-amber-500/30 rounded-xl p-3">
                <AlertTriangle className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                <p className="text-xs text-amber-700 dark:text-amber-300">
                  <strong>VITE_SUPABASE_URL</strong> dan <strong>VITE_SUPABASE_ANON_KEY</strong> belum diset di .env.
                  Sync realtime tidak aktif.
                </p>
              </div>
            )}

            {supabaseReady && (
              <div className="bg-emerald-50 border border-emerald-200 rounded-xl px-4 py-3 flex items-start gap-3">
                <div className="w-2 h-2 bg-emerald-500 rounded-full mt-1.5 animate-pulse shrink-0" />
                <div>
                  <p className="text-xs font-bold text-emerald-700">Realtime aktif</p>
                  <p className="text-xs text-emerald-600 mt-0.5">
                    Perubahan di device ini otomatis dikirim ke device lain secara real-time.
                    Push diblok selama initial pull saat startup.
                  </p>
                </div>
              </div>
            )}

            {/* Layout 2 Tombol Berdampingan */}
            {supabaseReady && (
              <div className="grid grid-cols-2 gap-2">
                {/* 1. Auto-Sync Berkala — jalan global di App.jsx tiap ~10 menit
                    + pas app di-background/dibuka lagi, gak peduli lagi di
                    layar mana (lihat App.jsx, bukan di sini lagi) */}
                <button onClick={handleToggleDailySync} className={`p-3 rounded-xl border-2 flex flex-col items-center justify-center text-center gap-1.5 transition-all ${dailySyncOn ? 'border-blue-500 bg-blue-50 dark:bg-blue-500/10 text-blue-700 dark:text-blue-300' : 'border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-500 dark:text-slate-400'}`}>
                  <Clock className="w-5 h-5" />
                  <p className="text-[10px] font-bold leading-tight">Auto-Sync<br />Berkala</p>
                  <div className={`text-[9px] font-bold px-2 py-0.5 rounded-full ${dailySyncOn ? 'bg-blue-500 text-white' : 'bg-slate-200 dark:bg-slate-700 text-slate-500 dark:text-slate-400'}`}>{dailySyncOn ? 'ON' : 'OFF'}</div>
                </button>

                {/* 2. Sync Manual Sekarang */}
                <button onClick={handleManualSync} disabled={isSyncing || isRestoring || !supabaseReady} className={`p-3 rounded-xl border-2 flex flex-col items-center justify-center text-center gap-1.5 transition-all ${isSyncing ? 'border-accent-500 bg-accent-50 dark:bg-accent-500/10 text-accent-700 dark:text-accent-300' : 'border-indigo-500 bg-indigo-50 dark:bg-indigo-500/10 text-indigo-700 dark:text-indigo-300 hover:bg-indigo-100 dark:hover:bg-indigo-500/20'}`}>
                  {isSyncing ? <RefreshCw className="w-5 h-5 animate-spin" /> : <CloudUpload className="w-5 h-5" />}
                  <p className="text-[10px] font-bold leading-tight">Manual<br />Sekarang</p>
                  <div className={`text-[9px] font-bold px-2 py-0.5 rounded-full ${isSyncing ? 'bg-accent-500 text-white' : 'bg-indigo-500 text-white'}`}>{isSyncing ? 'SYNC' : 'TAP'}</div>
                </button>
              </div>
            )}

            {/* Progress Bar Sync Manual — muncul cuma selagi isSyncing */}
            {supabaseReady && isSyncing && <SyncProgressBar progress={syncProgress} />}

            {/* Daftar record gagal — selagi sync (live dari syncProgress) ATAU
                setelah selesai (dari lastFailedItems, yang gak ke-reset). */}
            {supabaseReady && (
              <FailedSyncList items={isSyncing ? syncProgress?.failedItems : lastFailedItems} />
            )}

            {/* Info Waktu Sync Terakhir — disembunyikan sementara selagi progress bar tampil */}
            {supabaseReady && !isSyncing && (
              <div className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-3 flex items-center justify-between">
                <span className="flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400">
                  <RefreshCw className="w-3 h-3" />
                  {lastSyncTime
                    ? <span>Terakhir: <span className="font-bold text-slate-700 dark:text-slate-200">{lastSyncTime}</span></span>
                    : <span>Belum pernah sync</span>}
                </span>
              </div>
            )}

            {/* Restore dari server (belum butuh) */}
            {/* <div className="border-t border-slate-100 pt-3">
              <p className="text-xs text-slate-400 mb-2">
                Pindah HP atau install ulang? Tarik semua data dari cloud. Server adalah <strong>source of truth</strong>.
              </p>
              <button onClick={handleRestoreFromSupabase} disabled={isSyncing || isRestoring || !supabaseReady}
                className={`w-full py-3 rounded-xl font-bold text-sm transition-all flex items-center justify-center gap-2 border-2
                  ${isRestoring || !supabaseReady
                    ? 'border-slate-200 bg-slate-100 text-slate-400 cursor-not-allowed'
                    : 'border-blue-200 bg-blue-50 hover:bg-blue-100 text-blue-700'}`}
              >
                {isRestoring
                  ? <><RefreshCw className="w-4 h-4 animate-spin" /> Memulihkan...</>
                  : <><Upload className="w-4 h-4" /> Restore dari Server</>}
              </button>
            </div> */}
          </div>
        </div>

        {/* Export */}
        <div>
          <p className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-2 px-1">Export / Backup Lokal</p>
          <div className="space-y-2">
            <ActionItem icon={FileJson} label="Export Data (JSON)" sublabel="Backup dengan pilihan rentang tanggal"
              badge="Range" onClick={() => setDateRangeModal('json')}
              loading={loadingState['exportJson']} done={doneState['exportJson']}
              iconBgClass="bg-accent-50 dark:bg-accent-500/10" iconColorClass="text-accent-500 dark:text-accent-400" />
            <ActionItem icon={Sheet} label="Export ke Excel" sublabel="Laporan transaksi dengan filter tanggal"
              badge="Range" onClick={() => setDateRangeModal('excel')}
              loading={loadingState['exportExcel']} done={doneState['exportExcel']}
              iconBgClass="bg-green-50 dark:bg-green-500/10" iconColorClass="text-green-600 dark:text-green-400" />
          </div>
        </div>

        {/* Import Lokal */}
        <div>
          <p className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-2 px-1">Import dari File</p>
          <ActionItem icon={FileUp} label="Import dari JSON" sublabel="Pulihkan data dari file backup lokal"
            onClick={() => setImportModal('json')}
            loading={loadingState['importJson']} done={doneState['importJson']}
            iconBgClass="bg-accent-50 dark:bg-accent-500/10" iconColorClass="text-accent-500 dark:text-accent-400" />
        </div>

      </div>

      <style>{`
        @keyframes fadeInDown {
          from { opacity:0; transform:translateX(-50%) translateY(-8px); }
          to   { opacity:1; transform:translateX(-50%) translateY(0); }
        }
        @keyframes slideUp {
          from { opacity:0; transform:translateY(20px); }
          to   { opacity:1; transform:translateY(0); }
        }
      `}</style>
    </div>
  );
};

export default BackupView;
import React from "react";
import { Share2 } from "lucide-react";
import { useAppContext } from "../../../context/AppContext";
import { Capacitor } from '@capacitor/core';
import { Share } from '@capacitor/share';
import { Filesystem, Directory } from '@capacitor/filesystem';
import { pdf } from '@react-pdf/renderer';
import PayslipPDFDocument from './PayslipPDFDocument';
import { buildPayslipRows, countWorkDays } from '../utils/payrollLogic';

const PayslipModal = () => {
  const { payslipModal, setPayslipModal, formatRupiah } = useAppContext();
  if (!payslipModal.isOpen || !payslipModal.data) return null;
  const { data, month } = payslipModal;

  const basicPay = data.basicPay;
  const overtimePay = data.overtimePay || 0;

  // Header slip gaji (Upah per Jam & Bonus Full Time) HARUS pakai data
  // karyawan LIVE terkini — bukan data.employee (snapshot beku dari record
  // pertama periode ini). Beda dengan rincian tabel harian yang memang
  // sengaja pakai snapshot per-record biar histori bulan lalu gak berubah.
  const liveEmployee = (data.employees || []).find(e => e.id === data.employeeId) || data.employee;

  const monthLabel = new Date(`${month}-01`).toLocaleDateString('id-ID', { month: 'long', year: 'numeric' });

  const handleSharePDF = async () => {
    try {
      // Generate PDF
      const blob = await pdf(
        <PayslipPDFDocument
          data={data}
          liveEmployee={liveEmployee}
          monthLabel={monthLabel}
          formatRupiah={formatRupiah}
        />
      ).toBlob();

      const fileName = `slip-gaji-${data.employee.name}-${month}.pdf`;

      if (Capacitor.isNativePlatform()) {
        // Blob → base64 untuk Capacitor Filesystem
        const base64 = await new Promise((resolve, reject) => {
          const reader = new FileReader();
          reader.onloadend = () => resolve(reader.result.split(',')[1]);
          reader.onerror = reject;
          reader.readAsDataURL(blob);
        });

        const savedFile = await Filesystem.writeFile({
          path: fileName,
          data: base64,
          directory: Directory.Cache,
        });

        await Share.share({
          title: 'Slip Gaji',
          text: `Slip gaji ${data.employee.name} - ${monthLabel}`,
          url: savedFile.uri,
          dialogTitle: 'Bagikan Slip Gaji via',
        });
      } else {
        // Web: auto-download PDF
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = fileName;
        a.click();
        URL.revokeObjectURL(url);
      }
    } catch (error) {
      console.error('PDF Error:', error);
      if (error.name !== 'AbortError') {
        alert(`Gagal membuat PDF!\n\nError: ${error.message || JSON.stringify(error)}`);
      }
    }
  };

  // Baris "Rincian Pemasukan & Pengeluaran Harian" — SATU sumber kebenaran
  // yang sama dipakai dokumen PDF (PayslipPDFDocument), supaya yang dilihat
  // di layar & yang didownload selalu identik.
  const payslipRows = buildPayslipRows(data);
  const totalHariKerja = countWorkDays(data.records);

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm transition-opacity duration-300 print:bg-white print:p-0 overflow-y-auto">
      <style dangerouslySetInnerHTML={{
        __html: `
        @media print {
          body * { visibility: hidden; }
          #payslip-content, #payslip-content * { visibility: visible; }
          #payslip-content { 
            position: absolute; 
            left: 0; 
            top: 0; 
            width: 210mm; 
            margin: 0; 
            padding: 15mm; 
            box-shadow: none; 
            font-family: 'Inter', system-ui, sans-serif;
            color: black !important;
          }
          @page { size: A4; margin: 0; }
        }
      `}} />

      <div className="bg-white dark:bg-slate-900 rounded-lg w-full max-w-[800px] shadow-2xl relative font-sans text-sm animate-in zoom-in-95 duration-300 ease-out print:shadow-none print:w-[210mm] print:max-w-none my-8 flex flex-col max-h-[90vh] print:max-h-none print:my-0">
        <div id="payslip-content" className="p-8 print:p-0 overflow-y-auto custom-scrollbar flex-1">

          <div className="text-center border-b-2 border-slate-300 dark:border-slate-600 pb-6 mb-6 print:pb-4 print:mb-4">
            <h2 className="text-2xl font-black uppercase tracking-widest text-slate-800 dark:text-slate-100 mb-2 print:text-black">SLIP GAJI KARYAWAN</h2>
            <p className="text-sm text-slate-500 dark:text-slate-400 font-bold print:text-black">MAMAM AYAM</p>
            <p className="text-sm text-slate-500 dark:text-slate-400 mt-1 print:text-black">Periode: {monthLabel}</p>
          </div>

          <div className="flex justify-between mb-8 text-sm text-slate-700 dark:text-slate-200 print:text-black">
            {/* KOLOM KIRI */}
            <div>
              <div className="mb-2"><span className="inline-block w-32 text-slate-500 print:text-gray-600">Nama</span> <span className="font-bold">: {data.employee.name}</span></div>
              <div className="mb-2"><span className="inline-block w-32 text-slate-500 print:text-gray-600">Posisi</span> <span className="font-bold">: Karyawan</span></div>
              <div className="mb-2"><span className="inline-block w-32 text-slate-500 print:text-gray-600">Hari Kerja Masuk</span> <span className="font-bold">: {totalHariKerja} Hari</span></div>

              {/* --- TOTAL JAM KERJA DIPINDAH KESINI --- */}
              <div className="mb-2"><span className="inline-block w-32 text-slate-500 print:text-gray-600">Total Jam Kerja</span> <span className="font-bold">: {Number(data.totalHours).toFixed(1).replace('.', ',')} Jam</span></div>
            </div>

            {/* KOLOM KANAN */}
            <div className="text-right">
              {/* Total Jam Kerja sebelumnya ada di sini, sekarang dihapus */}
              <div className="mb-2"><span className="inline-block w-36 text-slate-500 print:text-gray-600">Upah per Jam</span> <span className="font-bold">: {formatRupiah(liveEmployee.hourlyRate)}</span></div>
              <div className="mb-2"><span className="inline-block w-36 text-slate-500 print:text-gray-600">Lembur per 30 Menit</span> <span className="font-bold">: {formatRupiah(data.overtimeRate || 0)}</span></div>
              <div className="mb-2"><span className="inline-block w-36 text-slate-500 print:text-gray-600">Bonus Full Time</span> <span className="font-bold">: {formatRupiah(liveEmployee.fullTimeBonus || 0)}</span></div>
            </div>
          </div>

          {/* TABEL ARUS KAS HARIAN */}
          <div className="mb-8">
            <h3 className="font-bold text-lg mb-4 text-slate-800 dark:text-slate-100 print:text-black border-b border-slate-200 dark:border-slate-700 pb-2">Rincian Pemasukan & Pengeluaran Harian</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-sm text-left text-slate-700 dark:text-slate-200 print:text-black border-collapse">
                <thead className="bg-slate-100 dark:bg-slate-800 print:bg-gray-100">
                  <tr>
                    <th className="py-2 px-3 font-bold border border-slate-200 dark:border-slate-700 print:border-gray-300">Tanggal & Jam</th>
                    <th className="py-2 px-3 font-bold border border-slate-200 dark:border-slate-700 print:border-gray-300">Keterangan</th>
                    <th className="py-2 px-3 font-bold border border-slate-200 dark:border-slate-700 print:border-gray-300 text-right">Pemasukan (+)</th>
                    <th className="py-2 px-3 font-bold border border-slate-200 dark:border-slate-700 print:border-gray-300 text-right">Pengeluaran (-)</th>
                  </tr>
                </thead>
                <tbody>
                  {payslipRows.map(({ rec, items }, i) => items.map((item, j) => (
                    <tr key={`${rec.id}-${j}`} className="border-b border-slate-200 dark:border-slate-700 print:border-gray-300">
                      {j === 0 ? (
                        <td className="py-2 px-3 border border-slate-200 dark:border-slate-700 print:border-gray-300 align-top whitespace-nowrap" rowSpan={items.length}>
                          <div className="font-semibold">{rec.dateStr}</div>
                          <div className="text-xs text-slate-500 print:text-gray-600 mt-1">
                            {rec.clockIn || '--:--'} s/d {rec.clockOut || '--:--'}
                          </div>
                        </td>
                      ) : null}
                      <td className="py-2 px-3 border border-slate-200 dark:border-slate-700 print:border-gray-300 align-top">{item.desc}</td>
                      <td className="py-2 px-3 border border-slate-200 dark:border-slate-700 print:border-gray-300 align-top text-right text-green-600 dark:text-green-400 print:text-black">
                        {item.in > 0 ? formatRupiah(item.in) : '-'}
                      </td>
                      <td className="py-2 px-3 border border-slate-200 dark:border-slate-700 print:border-gray-300 align-top text-right text-accent-600 dark:text-accent-400 print:text-black">
                        {item.out > 0 ? formatRupiah(item.out) : '-'}
                      </td>
                    </tr>
                  )))}
                  {payslipRows.length === 0 && (
                    <tr>
                      <td colSpan="4" className="py-4 text-center text-slate-500 border border-slate-200 print:border-gray-300">Tidak ada data harian.</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          <div className="flex justify-end mb-8 print:text-black text-sm text-slate-700 dark:text-slate-200">
            <div className="w-full md:w-1/2">
              <div className="flex justify-between py-2 border-b border-slate-200 dark:border-slate-700 print:border-gray-300">
                <span>Total Upah Dasar</span>
                <span className="font-bold">{formatRupiah(basicPay)}</span>
              </div>
              <div className="flex justify-between py-2 border-b border-slate-200 dark:border-slate-700 print:border-gray-300">
                <span>Total Tambahan</span>
                <span className="font-bold text-green-600 dark:text-green-400 print:text-black">(+) {formatRupiah(data.totalAdditions)}</span>
              </div>
              <div className="flex justify-between py-2 border-b border-slate-200 dark:border-slate-700 print:border-gray-300">
                <span>Total Potongan</span>
                <span className="font-bold text-accent-600 dark:text-accent-400 print:text-black">(-) {formatRupiah(data.totalDeductions)}</span>
              </div>
              <div className="flex justify-between py-3 mt-2 border-t-2 border-slate-800 dark:border-slate-100 print:border-black text-base font-black uppercase">
                <span>TOTAL DITERIMA</span>
                <span>{formatRupiah(data.netPay)}</span>
              </div>
            </div>
          </div>

          <div className="flex justify-between mt-16 text-sm text-center text-slate-800 dark:text-slate-100 print:text-black">
            <div className="w-1/3">
              <p>Penerima,</p>
              <br /><br /><br /><br />
              <p className="font-bold underline">({data.employee.name})</p>
            </div>
            <div className="w-1/3">
              <p>Mengetahui,</p>
              <br /><br /><br /><br />
              <p className="font-bold underline">( HRD / Manajemen )</p>
            </div>
          </div>

        </div>

        <div className="bg-slate-50 dark:bg-slate-800 p-4 rounded-b-lg border-t border-slate-200 dark:border-slate-700 flex gap-4 print:hidden mt-auto">
          <button onClick={handleSharePDF} className="flex-1 py-3 rounded-xl bg-slate-800 text-white font-bold shadow-lg hover:bg-slate-900 flex justify-center items-center gap-2 transition-colors">
            <Share2 className="w-5 h-5" /> Bagikan PDF
          </button>
          <button onClick={() => setPayslipModal({ isOpen: false, data: null })} className="flex-1 py-3 rounded-xl bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-100 border border-slate-300 dark:border-slate-600 font-bold hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
};

export default PayslipModal;
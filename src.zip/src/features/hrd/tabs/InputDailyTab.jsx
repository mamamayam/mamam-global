import React, { useState, useMemo, useEffect } from 'react';
import { useAppContext } from '../../../context/AppContext';
import { toLocalDateString, toLocalMonthString } from '../../../utils/formatters';
import { Card, Button, Input, Select, IconButton, Badge, SegmentedControl, Alert, SortModal, BulkSelectBar } from '../../../components/ui';
import CategoryModal from '../../../components/CategoryModal';
import { activeOnly, trashedOnly, markDeleted } from '../../../utils/softDelete';
import { useBulkSelect } from '../../../hook/useBulkSelect';
import {
  Wallet, Plus, Trash2, Save, History, Clock, Edit3, Settings2,
  ArrowUpDown, X, ChevronDown, ChevronRight, User,
} from 'lucide-react';
import {
  WORK_START_MINUTES, WORK_END_MINUTES, EARLY_OVERTIME_THRESHOLD_MINUTES, OVERTIME_THRESHOLD_MINUTES,
  LEMBUR_CATEGORY_KEYWORD, KASBON_CATEGORY_KEYWORD,
  getEmployeeStatus, calculateRegularMinutes, timeStrToMinutes, getOvertimeRate, calculateOvertimePay,
  AUTO_ADJUSTMENT_CATEGORIES, mergeAutoAdjustments,
  snapshotEmployeeForPayroll, resolveEmployeeForRecord,
  computeAttendanceFromLogs, calculateBolongMinutes,
} from '../utils/payrollLogic';

const StatField = ({ label, value, highlight }) => (
  <div className="bg-slate-50 dark:bg-slate-950 border border-slate-100 dark:border-slate-800 rounded-2xl px-3 py-2.5">
    <p className="text-[11px] font-bold text-slate-400 dark:text-slate-500 mb-1">{label}</p>
    <p className={`text-sm font-bold ${highlight ? 'text-emerald-700 dark:text-emerald-400' : 'text-slate-700 dark:text-slate-300'}`}>{value || '-'}</p>
  </div>
);

// computeAttendanceFromLogs (resolve status kehadiran 1 karyawan pada 1
// tanggal) sekarang tinggal di payrollLogic.js — jadi shared utility yang
// juga dipakai App.jsx buat watchdog backfill "Libur" di level root (lihat
// komentar lengkap di payrollLogic.js & App.jsx). Backfill retroaktif
// (karyawan yang gak absen SAMA SEKALI, tanpa log apa pun) juga sudah
// dipindah ke App.jsx, supaya ke-trigger begitu app dibuka lewat modul
// manapun — gak cuma pas tab Input Harian/Rekap Laporan/Absensi yang
// kebuka.

/* ─────────────────────────────────────────────────────── */
const AdjRow = ({ item, onRemove, formatRupiah }) => {
  const isAddition = item._type === 'addition';
  const isAuto = item.isAuto || AUTO_ADJUSTMENT_CATEGORIES.includes(item.category);
  return (
    <div className={`flex items-center justify-between gap-2 p-2.5 rounded-xl border transition-all duration-300 ${isAddition ? 'bg-emerald-50/60 dark:bg-emerald-500/10 border-emerald-100 dark:border-emerald-500/20' : 'bg-red-50/60 dark:bg-red-500/10 border-red-100 dark:border-red-500/20'}`}>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-1.5 flex-wrap">
          <span className={`text-[11px] font-bold px-1.5 py-0.5 rounded-full ${isAddition ? 'bg-emerald-100 dark:bg-emerald-500/20 text-emerald-700 dark:text-emerald-400' : 'bg-red-100 dark:bg-red-500/20 text-red-700 dark:text-red-400'}`}>{item.category}</span>
          {isAuto && <span className="text-[10px] font-semibold text-slate-400 dark:text-slate-500">Otomatis</span>}
        </div>
        {item.note && <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate mt-1">{item.note}</p>}
      </div>
      <div className="flex items-center gap-1.5 shrink-0">
        <span className={`text-sm font-bold ${isAddition ? 'text-emerald-700 dark:text-emerald-400' : 'text-red-700 dark:text-red-400'}`}>{isAddition ? '+' : '-'}{formatRupiah(item.amount)}</span>
        {!isAuto && <IconButton variant="delete" onClick={() => onRemove(item._type, item.id)}><Trash2 className="w-3.5 h-3.5" /></IconButton>}
      </div>
    </div>
  );
};
/* ─────────────────────────────────────────────────────── */

const InputDailyTab = () => {
  const {
    employees, triggerAlert, triggerConfirm,
    employeeDailyRecords, setEmployeeDailyRecords,
    additionCategories, setAdditionCategories,
    deductionCategories, setDeductionCategories,
    expenses, attendanceLog,
  } = useAppContext();

  const [dailyDate, setDailyDate] = useState(toLocalDateString());
  const [dailyEmpId, setDailyEmpId] = useState('');
  const [additions, setAdditions] = useState([]);
  const [deductions, setDeductions] = useState([]);
  const [catModalType, setCatModalType] = useState(null);
  const [showTrash, setShowTrash] = useState(false);
  const [dailySortKey, setDailySortKey] = useState('date-desc');
  const [isDailySortOpen, setIsDailySortOpen] = useState(false);
  const [expandedRecordId, setExpandedRecordId] = useState(null);
  const [collapsedEmployees, setCollapsedEmployees] = useState(new Set());
  const [isSelecting, setIsSelecting] = useState(false);

  const [filterMode, setFilterMode] = useState('hari-ini'); // 'hari-ini' | 'kemarin' | 'bulan-ini' | 'semua' | 'tanggal-terpilih'
  const [filterStartDate, setFilterStartDate] = useState('');
  const [filterEndDate, setFilterEndDate] = useState('');

  const matchesDateFilter = (dateStr) => {
    if (!dateStr) return true;
    if (filterMode === 'semua') return true;
    if (filterMode === 'hari-ini') return dateStr === toLocalDateString();
    if (filterMode === 'kemarin') {
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      return dateStr === toLocalDateString(yesterday);
    }
    if (filterMode === 'bulan-ini') return dateStr.slice(0, 7) === toLocalMonthString();
    if (filterMode === 'tanggal-terpilih') {
      if (!filterStartDate) return true;
      // Hybrid: kalau filterEndDate kosong, otomatis single-day (= filterStartDate)
      const end = filterEndDate || filterStartDate;
      return dateStr >= filterStartDate && dateStr <= end;
    }
    return true;
  };

  const [adjType, setAdjType] = useState('addition');
  const [adjCategory, setAdjCategory] = useState('');
  const [adjAmount, setAdjAmount] = useState('');
  const [adjNote, setAdjNote] = useState('');
  const [adjPaymentMethod, setAdjPaymentMethod] = useState('Tunai');

  const [editingRecord, setEditingRecord] = useState(null);
  const [editAdditions, setEditAdditions] = useState([]);
  const [editDeductions, setEditDeductions] = useState([]);
  const [editAdjType, setEditAdjType] = useState('addition');
  const [editAdjCategory, setEditAdjCategory] = useState('');
  const [editAdjAmount, setEditAdjAmount] = useState('');
  const [editAdjNote, setEditAdjNote] = useState('');
  const [editAdjPaymentMethod, setEditAdjPaymentMethod] = useState('Tunai');
  const [editClockIn, setEditClockIn] = useState('');
  const [editClockOut, setEditClockOut] = useState('');

  const formatRupiah = (amount) => `Rp${Number(amount || 0).toLocaleString('id-ID')}`;
  const formatJam = (hours) => {
    const h = Number(hours) || 0;
    if (h <= 0) return '';
    return (Math.ceil(Number(h.toFixed(4)) * 10) / 10).toFixed(1).replace('.', ',');
  };
  const toggleEmployeeCollapse = (empId) => {
    setCollapsedEmployees(prev => {
      const next = new Set(prev);
      next.has(empId) ? next.delete(empId) : next.add(empId);
      return next;
    });
  };

  /* ── Helper SSoT: Ambil Kasbon dinamis dari Expenses ── */
  const getDerivedKasbon = (empId, dateStr) => {
    if (!expenses || expenses.length === 0) return [];
    return expenses
      .filter(e => !e.deletedAt && e.employeeId === empId && toLocalDateString(e.date) === dateStr && (e.category === 'Kasbon Karyawan' || e.category.toLowerCase().includes('kasbon')))
      .map(e => ({
        id: e.id,
        category: 'Kasbon (Dompet)',
        amount: e.amount,
        note: e.note,
        _type: 'deduction',
        isAuto: true
      }));
  };

  const hasAdjustments = useMemo(() => {
    const r = employeeDailyRecords.find(r => !r.deletedAt && r.employeeId === dailyEmpId && r.dateStr === dailyDate);
    return r && (r.additions?.length > 0 || r.deductions?.length > 0);
  }, [dailyEmpId, dailyDate, employeeDailyRecords]);

  // Generator record harian otomatis: begitu attendanceLog berubah (atau
  // pas komponen ini mount), resolve ulang status kehadiran tiap pasangan
  // employeeId|dateStr yang punya minimal 1 log hari itu, lalu tulis/update
  // employeeDailyRecords via computeAttendanceFromLogs (payrollLogic.js).
  //
  // Backfill retroaktif untuk karyawan yang SAMA SEKALI gak punya log apa
  // pun (gak login/logout sama sekali) TIDAK lagi ditangani di sini —
  // sekarang jadi watchdog terpisah di App.jsx (level root), supaya
  // ke-trigger begitu app dibuka lewat modul MANAPUN (Kasir, dst), bukan
  // cuma pas tab Input Harian/Rekap Laporan/Absensi yang kebuka. Lihat
  // useEffect "Watchdog backfill Libur otomatis" di App.jsx untuk detailnya.
  useEffect(() => {
    if (!attendanceLog) return;
    const activeLogs = activeOnly(attendanceLog);
    if (activeLogs.length === 0) return;

    const pairsMap = new Map();
    activeLogs.forEach(r => {
      pairsMap.set(`${r.employeeId}|${r.dateStr}`, { employeeId: r.employeeId, dateStr: r.dateStr });
    });

    setEmployeeDailyRecords(prev => {
      let next = [...prev]; let changed = false;
      pairsMap.forEach(({ employeeId: empId, dateStr }) => {
        const result = computeAttendanceFromLogs(empId, dateStr, attendanceLog);
        if (result.status === 'Belum Absen' && !result.isDayOff) return;
        const emp = employees.find(e => e.id === empId);
        const prevIndex = next.findIndex(r => !r.deletedAt && r.employeeId === empId && r.dateStr === dateStr);
        const prevExisting = prevIndex >= 0 ? next[prevIndex] : null;

        // Tarif karyawan buat record ini: PRIORITASKAN snapshot yang sudah
        // dibekukan sebelumnya (biar tarif lama gak ikut berubah kalau
        // tarif karyawan diedit belakangan). Record yang belum pernah punya
        // snapshot (baru dibuat, atau record lama dari sebelum fitur ini
        // ada) dibekukan dari data karyawan TERKINI sekarang juga.
        const employeeSnapshot = prevExisting?.employeeSnapshot || snapshotEmployeeForPayroll(emp);

        const baseFields = prevExisting?.isManualOverride ? 
          { 
            isDayOff: prevExisting.isDayOff, 
            clockIn: prevExisting.clockIn, 
            clockOut: prevExisting.clockOut, 
            hoursWorked: prevExisting.hoursWorked, 
            bolongMinutes: prevExisting.bolongMinutes, 
            overtimeMinutes: prevExisting.overtimeMinutes,
            isManualOverride: true 
          } : 
          { 
            isDayOff: result.isDayOff, 
            clockIn: result.clockIn, 
            clockOut: result.clockOut, 
            hoursWorked: result.hoursWorked, 
            bolongMinutes: result.bolongMinutes, 
            overtimeMinutes: result.overtimeMinutes 
          };

        const recordSnapshot = { ...prevExisting, ...baseFields, employeeId: empId, dateStr };
        const recalculatedAdditions = mergeAutoAdjustments(prevExisting?.additions, recordSnapshot, employeeSnapshot);

        // Record lama yang belum punya employeeSnapshot dianggap "berubah"
        // walau field absensi/additions-nya kebetulan identik — supaya
        // tarifnya ke-bekukan permanen begitu record ini kesentuh effect ini.
        const needsSnapshotBackfill = !!prevExisting && !prevExisting.employeeSnapshot;

        const isSame = prevExisting && !needsSnapshotBackfill &&
          prevExisting.isDayOff === baseFields.isDayOff &&
          prevExisting.clockIn === baseFields.clockIn &&
          prevExisting.clockOut === baseFields.clockOut &&
          prevExisting.hoursWorked === baseFields.hoursWorked &&
          (prevExisting.bolongMinutes || 0) === baseFields.bolongMinutes &&
          (prevExisting.overtimeMinutes || 0) === baseFields.overtimeMinutes &&
          JSON.stringify(prevExisting.additions || []) === JSON.stringify(recalculatedAdditions);
        if (isSame) return;

        changed = true;
        if (prevExisting) {
          next[prevIndex] = { ...prevExisting, ...baseFields, additions: recalculatedAdditions, employeeSnapshot };
        } else {
          // ID DETERMINISTIK (bukan random) — supaya kalau 2 device
          // sama-sama memproses attendanceLog yang sama untuk
          // employeeId+dateStr yang sama sebelum sempat saling sync,
          // keduanya menghasilkan `id` yang SAMA. Sync engine upsert by
          // `id` (lihat syncKeys.js TRANSACTION_KEYS) jadi otomatis
          // menyatu jadi 1 baris, bukan 2 record duplikat yang kehitung
          // dobel di laporan (jam kerja, telat, dst). Konsisten dengan
          // pola AUTO-LIBUR-BACKFILL-* di App.jsx yang sudah aman dari
          // race yang sama.
          next.unshift({ id: `REC-${empId}-${dateStr}`, employeeId: empId, date: new Date(dateStr), dateStr, ...baseFields, additions: recalculatedAdditions, deductions: [], employeeSnapshot });
        }
      });
      return changed ? next : prev;
    });
  }, [attendanceLog, employees, setEmployeeDailyRecords]);

  useEffect(() => {
    if (dailyEmpId && dailyDate) {
      const r = employeeDailyRecords.find(r => !r.deletedAt && r.employeeId === dailyEmpId && r.dateStr === dailyDate);
      setAdditions(r?.additions || []);
      setDeductions(r?.deductions || []);
    } else {
      setAdditions([]); setDeductions([]);
    }
  }, [dailyEmpId, dailyDate, employeeDailyRecords]);

  const handleAddAdjustment = () => {
    if (!adjCategory) return triggerAlert('Pilih kategori terlebih dahulu!');
    if (!adjAmount || Number(adjAmount) <= 0) return triggerAlert('Masukkan nominal yang valid!');
    const newItem = { id: Date.now() + Math.random(), category: adjCategory, amount: Number(adjAmount), note: adjNote, paymentMethod: adjType === 'deduction' ? adjPaymentMethod : null };
    if (adjType === 'addition') setAdditions(prev => [...prev, newItem]);
    else setDeductions(prev => [...prev, newItem]);
    setAdjAmount(''); setAdjNote('');
  };

  const handleRemoveAdjustment = (type, id) => {
    if (type === 'addition') setAdditions(prev => prev.filter(a => a.id !== id));
    else setDeductions(prev => prev.filter(d => d.id !== id));
  };

  const handleSaveDailyRecord = () => {
    if (!dailyEmpId || !dailyDate) return triggerAlert('Pilih karyawan & tanggal terlebih dahulu!');
    const validDeductions = deductions.filter(d => d.category && d.amount > 0);
    const emp = employees.find(e => e.id === dailyEmpId);
    const validAdditions = additions.filter(a => a.category && a.amount > 0);

    setEmployeeDailyRecords(prev => {
      const existing = prev.find(r => !r.deletedAt && r.employeeId === dailyEmpId && r.dateStr === dailyDate);
      if (existing) {
        // Prioritaskan tarif yang sudah dibekukan di record ini sebelumnya;
        // record lama yang belum punya snapshot dibekukan sekarang.
        const employeeSnapshot = existing.employeeSnapshot || snapshotEmployeeForPayroll(emp);
        const finalAdditions = mergeAutoAdjustments(validAdditions, existing, employeeSnapshot);
        return prev.map(r => r.id === existing.id ? { ...r, additions: finalAdditions, deductions: validDeductions, employeeSnapshot } : r);
      }
      const computed = computeAttendanceFromLogs(dailyEmpId, dailyDate, attendanceLog);
      const newRecordBase = { employeeId: dailyEmpId, dateStr: dailyDate, isDayOff: computed.isDayOff, clockIn: computed.clockIn, clockOut: computed.clockOut, hoursWorked: computed.hoursWorked, bolongMinutes: computed.bolongMinutes, overtimeMinutes: computed.overtimeMinutes };
      // Record baru: bekukan tarif karyawan TERKINI sekarang juga, supaya
      // gak berubah lagi walau tarif karyawan diedit di kemudian hari.
      const employeeSnapshot = snapshotEmployeeForPayroll(emp);
      const finalAdditions = mergeAutoAdjustments(validAdditions, newRecordBase, employeeSnapshot);
      // ID deterministik (employeeId+dateStr) — konsisten dengan watchdog
      // auto-attendance di atas, supaya kalau race dengan device lain yang
      // juga insert record baru untuk hari yang sama, sync engine upsert
      // jadi 1 baris (bukan duplikat). Lihat komentar lengkap di watchdog
      // useEffect di atas.
      return [{ id: `REC-${dailyEmpId}-${dailyDate}`, date: new Date(dailyDate), ...newRecordBase, additions: finalAdditions, deductions: validDeductions, employeeSnapshot }, ...prev];
    });
    triggerAlert(hasAdjustments ? 'Perubahan berhasil diupdate!' : 'Data berhasil disimpan!');
  };

  const handleDeleteRecord = (rec) => {
    if (showTrash) {
      triggerConfirm('Apakah Anda yakin ingin menghapus permanen data ini? Tindakan ini tidak dapat dibatalkan.', () => {
        setEmployeeDailyRecords(prev => prev.filter(r => r.id !== rec.id));
        triggerAlert('Data berhasil dihapus secara permanen!');
      });
    } else {
      setEmployeeDailyRecords(prev => prev.map(r => r.id === rec.id ? markDeleted(r) : r));
      triggerAlert('Data berhasil dipindahkan ke Recycle Bin!');
    }
  };

  const handleOpenEdit = (rec) => {
    setEditingRecord(rec);
    setEditAdditions(rec.additions || []);
    setEditDeductions(rec.deductions || []);
    setEditAdjType('addition');
    setEditAdjCategory(''); setEditAdjAmount(''); setEditAdjNote(''); setEditAdjPaymentMethod('Tunai');
    setEditClockIn(rec.clockIn || '');
    setEditClockOut(rec.clockOut || '');
  };

  const handleCloseEdit = () => setEditingRecord(null);

  const handleEditAddAdjustment = () => {
    if (!editAdjCategory) return triggerAlert('Pilih kategori terlebih dahulu!');
    if (!editAdjAmount || Number(editAdjAmount) <= 0) return triggerAlert('Masukkan nominal yang valid!');
    const newItem = { id: Date.now() + Math.random(), category: editAdjCategory, amount: Number(editAdjAmount), note: editAdjNote, paymentMethod: editAdjType === 'deduction' ? editAdjPaymentMethod : null };
    if (editAdjType === 'addition') setEditAdditions(prev => [...prev, newItem]);
    else setEditDeductions(prev => [...prev, newItem]);
    setEditAdjAmount(''); setEditAdjNote('');
  };

  const handleEditRemoveAdjustment = (type, id) => {
    if (type === 'addition') setEditAdditions(prev => prev.filter(a => a.id !== id));
    else setEditDeductions(prev => prev.filter(d => d.id !== id));
  };

  const handleSaveEdit = () => {
    if (!editingRecord) return;
    const emp = employees.find(e => e.id === editingRecord.employeeId);
    const validAdditions = editAdditions.filter(a => a.category && a.amount > 0);
    const validDeductions = editDeductions.filter(d => d.category && d.amount > 0);
    
    let updatedFields = {};
    let isManualOverride = editingRecord.isManualOverride || false;

    // [FIX] Kontradiksi isDayOff:true + jam kerja valid harus ke-clear
    // begitu admin menyimpan record ini lewat modal edit, TERLEPAS apakah
    // dia benar-benar mengetik ulang editClockIn/editClockOut atau cuma
    // buka-lihat-simpan tanpa mengubah nilainya. Dicek TERPISAH dari
    // kondisi "nilai berubah" di bawah — kalau digabung ke kondisi itu
    // saja, record yang SUDAH kontradiktif dari sebelum fix ini (isDayOff
    // true tapi editClockIn/editClockOut form-nya sudah keisi persis sama
    // dengan clockIn/clockOut tersimpan) gak akan pernah ke-trigger karena
    // "tidak ada perubahan nilai" — padahal justru itu yang perlu
    // dibersihkan. Ini pasangan dari badge "⚠️ Cek Data" di tabel record.
    const clearsDayOffContradiction = editingRecord.isDayOff && editClockIn && editClockOut;

    if (editClockIn !== editingRecord.clockIn || editClockOut !== editingRecord.clockOut || clearsDayOffContradiction) {
      isManualOverride = true;
      const cIn = editClockIn;
      const cOut = editClockOut;
      let cHours = 0, cOvertime = 0;

      // [FIX] bolongMinutes HARUS dihitung ulang dari attendanceLog mentah
      // hari itu (pakai fallback jam keluar yang BARU diinput admin),
      // bukan dipertahankan dari nilai lama editingRecord.bolongMinutes.
      // Sebelumnya kalau admin koreksi clockIn/clockOut manual (mis. buat
      // memperbaiki jam pulang yang salah tercatat auto-close-dari-bolong),
      // bolongMinutes yang dipakai buat ngurangin rawHours tetap angka LAMA
      // yang sudah gak relevan sama rentang jam yang baru — hasil
      // hoursWorked/uang lembur bisa keliru padahal koreksinya sendiri
      // sudah benar. calculateBolongMinutes ini SATU fungsi yang sama
      // dipakai computeAttendanceFromLogs, jadi hasilnya konsisten dengan
      // cara sistem menghitung bolong di jalur otomatis.
      const empLogsToday = activeOnly(attendanceLog ?? [])
        .filter(r => r.employeeId === editingRecord.employeeId && r.dateStr === editingRecord.dateStr)
        .sort((a, b) => new Date(a.date) - new Date(b.date));
      const bolongFallbackEnd = cOut ? new Date(`${editingRecord.dateStr}T${cOut}:00`) : new Date();
      const cBolong = calculateBolongMinutes(empLogsToday, bolongFallbackEnd);

      if (cIn && cOut) {
        const inMins = timeStrToMinutes(cIn);
        const outMins = timeStrToMinutes(cOut);
        const earlyOvertimeMins = inMins <= EARLY_OVERTIME_THRESHOLD_MINUTES ? WORK_START_MINUTES - inMins : 0;
        const lateOvertimeMins = outMins >= OVERTIME_THRESHOLD_MINUTES ? outMins - WORK_END_MINUTES : 0;
        cOvertime = earlyOvertimeMins + lateOvertimeMins;
        
        const regularMinutes = calculateRegularMinutes(cIn, cOut, earlyOvertimeMins, lateOvertimeMins);
        const rawHours = Number((regularMinutes / 60).toFixed(2));
        const netHours = Number((rawHours - (cBolong / 60)).toFixed(4));
        cHours = netHours > 0 ? Math.ceil(netHours * 10) / 10 : 0;
      }

      updatedFields = {
        clockIn: cIn,
        clockOut: cOut,
        hoursWorked: cHours,
        overtimeMinutes: cOvertime,
        isManualOverride,
        // [FIX] isDayOff sebelumnya TIDAK PERNAH ikut di-reset di sini —
        // modal edit ini gak punya toggle "Libur" eksplisit (isDayOff cuma
        // ditampilkan sebagai badge read-only di tabel), jadi kalau record
        // ini sebelumnya kesimpen isDayOff:true (dari watchdog toAutoLibur,
        // backfill App.jsx, atau input manual lama), lalu admin ngisi
        // editClockIn/editClockOut buat mengoreksi jam masuk-pulang yang
        // seharusnya, isDayOff:true itu tetap nempel TANPA admin sadar —
        // hasilnya SATU record kesimpen isDayOff:true BERSAMAAN dengan
        // clockIn/clockOut/hoursWorked yang valid, kontradiktif secara
        // logika ("libur otomatis SAMA jam kerja otomatis").
        // Mengisi cIn DAN cOut sekaligus adalah sinyal gak ambigu bahwa
        // admin menyatakan karyawan ini HADIR di rentang jam tsb, jadi
        // isDayOff harus ikut di-clear jadi false bersamanya.
        isDayOff: !(cIn && cOut) && editingRecord.isDayOff,
      };
    }

    const recordSnapshot = { ...editingRecord, ...updatedFields };
    // Prioritaskan tarif yang sudah dibekukan waktu record ini pertama kali
    // dibuat — supaya koreksi jam masuk/pulang gak diam-diam ikut menghitung
    // ulang pakai tarif karyawan yang mungkin sudah berubah sejak saat itu.
    // Record lama yang belum punya snapshot dibekukan sekarang.
    const employeeSnapshot = editingRecord.employeeSnapshot || snapshotEmployeeForPayroll(emp);
    const finalAdditions = mergeAutoAdjustments(validAdditions, recordSnapshot, employeeSnapshot);
    
    setEmployeeDailyRecords(prev => prev.map(r => r.id === editingRecord.id ? { ...r, ...updatedFields, additions: finalAdditions, deductions: validDeductions, employeeSnapshot } : r));
    triggerAlert('Perubahan berhasil disimpan!');
    handleCloseEdit();
  };

  const hasUnsavedAdjustments = useMemo(() => {
    const existing = employeeDailyRecords.find(r => !r.deletedAt && r.employeeId === dailyEmpId && r.dateStr === dailyDate);
    return JSON.stringify(additions) !== JSON.stringify(existing?.additions || []) || JSON.stringify(deductions) !== JSON.stringify(existing?.deductions || []);
  }, [additions, deductions, dailyEmpId, dailyDate, employeeDailyRecords]);

  // Derived Kasbon Logic for Main Form
  const derivedKasbon = useMemo(() => getDerivedKasbon(dailyEmpId, dailyDate), [expenses, dailyEmpId, dailyDate]);
  
  const adjustmentRows = useMemo(() => ([
    ...additions.map(a => ({ ...a, _type: 'addition' })), 
    ...deductions.map(d => ({ ...d, _type: 'deduction' })),
    ...derivedKasbon
  ]), [additions, deductions, derivedKasbon]);
  
  const totalAdditions = useMemo(() => additions.reduce((s, a) => s + (Number(a.amount) || 0), 0), [additions]);
  const totalDeductions = useMemo(() => 
    deductions.reduce((s, d) => s + (Number(d.amount) || 0), 0) + 
    derivedKasbon.reduce((s, d) => s + (Number(d.amount) || 0), 0), 
  [deductions, derivedKasbon]);
  
  const netAdjustment = totalAdditions - totalDeductions;

  // Derived Kasbon Logic for Edit Modal
  const editDerivedKasbon = useMemo(() => editingRecord ? getDerivedKasbon(editingRecord.employeeId, editingRecord.dateStr) : [], [expenses, editingRecord]);
  
  const editAdjRows = useMemo(() => ([
    ...editAdditions.map(a => ({ ...a, _type: 'addition' })), 
    ...editDeductions.map(d => ({ ...d, _type: 'deduction' })),
    ...editDerivedKasbon
  ]), [editAdditions, editDeductions, editDerivedKasbon]);
  
  const editTotalAdditions = useMemo(() => editAdditions.reduce((s, a) => s + (Number(a.amount) || 0), 0), [editAdditions]);
  const editTotalDeductions = useMemo(() => 
    editDeductions.reduce((s, d) => s + (Number(d.amount) || 0), 0) + 
    editDerivedKasbon.reduce((s, d) => s + (Number(d.amount) || 0), 0), 
  [editDeductions, editDerivedKasbon]);
  
  const editNetAdjustment = editTotalAdditions - editTotalDeductions;
  const editingEmpName = editingRecord ? resolveEmployeeForRecord(editingRecord, employees)?.name : '';

  const groupedRecords = useMemo(() => {
    const rawList = (showTrash ? trashedOnly(employeeDailyRecords) : activeOnly(employeeDailyRecords))
      .filter(rec => matchesDateFilter(rec.dateStr));
    const groups = new Map();
    rawList.forEach(rec => {
      if (!groups.has(rec.employeeId)) groups.set(rec.employeeId, []);
      groups.get(rec.employeeId).push(rec);
    });

    const grouped = Array.from(groups.entries()).map(([, recs]) => ({
      // Snapshot record pertama di grup ini dipakai buat label nama —
      // konsisten sama prinsip immutable history, dan tetap kebaca walau
      // karyawannya sudah dihapus dari data master (lihat handleDeleteEmployee).
      employee: resolveEmployeeForRecord(recs[0], employees),
      records: recs.sort((a, b) => new Date(b.date) - new Date(a.date)),
    }));

    if (dailySortKey === 'name-asc') {
      grouped.sort((a, b) => (a.employee?.name || '').localeCompare(b.employee?.name || ''));
    } else {
      grouped.sort((a, b) => new Date(b.records[0]?.date) - new Date(a.records[0]?.date));
    }

    return grouped;
  }, [employeeDailyRecords, showTrash, dailySortKey, employees, filterMode, filterStartDate, filterEndDate]);

  const allVisibleRecords = useMemo(() => groupedRecords.flatMap(g => g.records), [groupedRecords]);
  const { selectedIds, allSelected, toggleOne: toggleSelectOne, toggleAll: toggleSelectAll, reset: resetSelection, count } = useBulkSelect(allVisibleRecords);

  const handleBulkSoftDelete = () => {
    const ids = [...selectedIds];
    if (ids.length === 0) return;
    triggerConfirm(`Pindahkan ${ids.length} data input terpilih ke Recycle Bin?`, () => {
      setEmployeeDailyRecords(prev => prev.map(r => selectedIds.has(r.id) ? markDeleted(r) : r));
      resetSelection();
      triggerAlert('Data terpilih dipindahkan ke Recycle Bin.');
    });
  };

  const handleBulkPermanentDelete = () => {
    const ids = [...selectedIds];
    if (ids.length === 0) return;
    triggerConfirm(`Hapus PERMANEN ${ids.length} data input terpilih? Tindakan ini tidak bisa dibatalkan.`, () => {
      setEmployeeDailyRecords(prev => prev.filter(r => !selectedIds.has(r.id)));
      resetSelection();
      triggerAlert('Data terpilih dihapus permanen.');
    });
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-full w-full min-w-0 animate-in fade-in slide-in-from-right-4 duration-300">
      {/* ─── KOLOM KIRI ─── */}
      <div className="lg:col-span-1 flex flex-col gap-6 w-full min-w-0">
        <div>
          <Card padding="lg" className="flex flex-col h-fit relative">
            <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Wallet className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                <h3 className="font-heading font-bold">Tambahan & Potongan</h3>
              </div>
              {hasAdjustments && <Badge variant="warning" className="animate-in zoom-in duration-200">Mode Edit</Badge>}
            </div>

            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <Input type="date" label="Tanggal" variant="muted" value={dailyDate} onChange={e => setDailyDate(e.target.value)} />
                <Select label="Karyawan" variant="muted" value={dailyEmpId} onChange={e => setDailyEmpId(e.target.value)}>
                  <option value="">Pilih Karyawan</option>
                  {employees.filter(emp => getEmployeeStatus(emp) !== 'resign' || emp.id === dailyEmpId).map(emp => (
                    <option key={emp.id} value={emp.id}>{emp.name}</option>
                  ))}
                </Select>
              </div>

              {dailyEmpId && hasAdjustments && (
                <Alert type="callout" variant="info">Mengedit rincian pada <strong>{dailyDate}</strong>.</Alert>
              )}

              {!dailyEmpId && (
                <p className="text-xs text-slate-400 text-center py-6">Pilih karyawan dulu buat mulai input tambahan/potongan & simpan data harian.</p>
              )}

              {dailyEmpId && (
                <>
                  <SegmentedControl
                    options={[{ value: 'addition', label: 'Penghasilan (+)', tone: 'green' }, { value: 'deduction', label: 'Potongan (-)', tone: 'red' }]}
                    value={adjType}
                    onChange={(val) => { setAdjType(val); setAdjCategory(''); }}
                  />
                  <div>
                    <label className="flex justify-between text-xs font-bold text-slate-500 mb-1.5">
                      Kategori
                      <Button type="button" size="xs" variant="secondary" onClick={() => setCatModalType(adjType)} icon={<Settings2 className="w-3 h-3" />}>Kelola</Button>
                    </label>
                    <Select variant="muted" value={adjCategory} onChange={e => setAdjCategory(e.target.value)}>
                      <option value="">Pilih Kategori</option>
                      {adjType === 'addition'
                        ? [...new Set(additionCategories)].filter(c => !c.toLowerCase().includes(LEMBUR_CATEGORY_KEYWORD)).map(c => <option key={c} value={c}>{c}</option>)
                        : [...new Set(deductionCategories)].filter(c => !c.toLowerCase().includes(KASBON_CATEGORY_KEYWORD)).map(c => <option key={c} value={c}>{c}</option>)
                      }
                    </Select>
                  </div>
                  <Input type="number" label="Nominal" variant="muted" icon={<span>Rp</span>} value={adjAmount} onChange={e => setAdjAmount(e.target.value)} />
                  <Input label="Catatan" variant="muted" value={adjNote} onChange={e => setAdjNote(e.target.value)} />
                  {adjType === 'deduction' && (
                    <div>
                      <label className="text-xs font-bold text-slate-500 mb-1.5 block">Metode Pembayaran</label>
                      <SegmentedControl options={[{ value: 'Tunai', label: 'Tunai' }, { value: 'Non-Tunai', label: 'Non-Tunai' }]} value={adjPaymentMethod} onChange={setAdjPaymentMethod} />
                    </div>
                  )}
                  <Button variant={adjType === 'addition' ? 'success' : 'danger'} size="full" icon={<Plus className="w-4 h-4" />} onClick={handleAddAdjustment}>
                    {adjType === 'addition' ? 'Tambah Penghasilan' : 'Tambah Potongan'}
                  </Button>

                  <div className="pt-3 border-t border-slate-100">
                    <p className="text-xs font-bold text-slate-500 mb-2">Rincian Transaksi</p>
                    {adjustmentRows.length === 0
                      ? <p className="text-xs text-slate-400 text-center py-3">Belum ada tambahan/potongan.</p>
                      : <div className="space-y-2">{adjustmentRows.map(item => <AdjRow key={item.id} item={item} onRemove={handleRemoveAdjustment} formatRupiah={formatRupiah} />)}</div>
                    }
                  </div>

                  {adjustmentRows.length > 0 && (
                    <div className="space-y-1 pt-3 border-t border-slate-100 text-xs">
                      <div className="flex justify-between text-slate-500"><span>Total Tambahan</span><span className="font-bold text-emerald-700 dark:text-emerald-400">+{formatRupiah(totalAdditions)}</span></div>
                      <div className="flex justify-between text-slate-500"><span>Total Potongan</span><span className="font-bold text-red-700">-{formatRupiah(totalDeductions)}</span></div>
                      <div className="flex justify-between font-bold text-slate-800 pt-1.5 border-t border-slate-100"><span>Net</span><span>{netAdjustment >= 0 ? '+' : ''}{formatRupiah(netAdjustment)}</span></div>
                    </div>
                  )}

                  {hasUnsavedAdjustments && <Alert type="callout" variant="warning">Ada perubahan yang belum disimpan.</Alert>}

                  <Button variant="primary" size="full" icon={<Save className="w-4 h-4" />} onClick={handleSaveDailyRecord}>
                    {hasAdjustments ? 'Simpan Perubahan (Update)' : 'Simpan Data'}
                  </Button>
                </>
              )}
            </div>
          </Card>
        </div>
      </div>

      {/* ─── KOLOM KANAN ─── */}
      <Card padding="none" className="lg:col-span-2 flex flex-col h-[700px] w-full min-w-0">
        <div className="p-4 border-b border-slate-100 bg-slate-50 rounded-t-2xl space-y-3">
          <div className="flex flex-wrap gap-2 justify-between items-center">
            <h3 className="font-heading font-bold flex items-center gap-2 shrink-0">
              <History className="w-4 h-4" /> {showTrash ? 'Recycle Bin' : 'Riwayat Input'}
            </h3>
            <div className="flex flex-wrap gap-2 min-w-0">
              <button onClick={() => { setShowTrash(!showTrash); resetSelection(); setIsSelecting(false); }} className="text-xs font-bold text-slate-500 shrink-0">
                {showTrash ? 'Kembali' : 'Recycle Bin'}
              </button>
              <button
                onClick={() => { if (isSelecting) resetSelection(); setIsSelecting(v => !v); }}
                className={`text-xs font-bold px-2 py-1 rounded-lg transition-colors shrink-0 ${isSelecting ? 'bg-emerald-50 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400' : 'text-slate-500 dark:text-slate-400'}`}
              >
                {isSelecting ? 'Batal' : 'Pilih'}
              </button>
              <button onClick={() => setIsDailySortOpen(true)} className="flex items-center gap-1 text-xs font-bold text-slate-500 border rounded-lg px-2 py-1.5 shrink-0">
                <ArrowUpDown className="w-3.5 h-3.5" /> Urutkan
              </button>
            </div>
          </div>

          {!showTrash && (
            <div className="flex flex-wrap items-center gap-2 min-w-0">
              <Select value={filterMode} onChange={e => setFilterMode(e.target.value)} className="py-1.5 px-2 text-xs font-bold shrink-0">
                <option value="hari-ini">Hari Ini</option>
                <option value="kemarin">Kemarin</option>
                <option value="bulan-ini">Bulan Ini</option>
                <option value="semua">Semua</option>
                <option value="tanggal-terpilih">Tanggal Terpilih</option>
              </Select>
              {filterMode === 'tanggal-terpilih' && (
                <div className="flex items-center gap-1 flex-wrap min-w-0">
                  <Input type="date" value={filterStartDate} onChange={e => setFilterStartDate(e.target.value)} max={filterEndDate || undefined} className="py-1.5 px-2 text-xs font-bold shrink-0 min-w-0 max-w-[130px]" />
                  <span className="text-xs text-slate-400 shrink-0">-</span>
                  <Input type="date" value={filterEndDate} onChange={e => setFilterEndDate(e.target.value)} min={filterStartDate || undefined} className="py-1.5 px-2 text-xs font-bold shrink-0 min-w-0 max-w-[130px]" />
                </div>
              )}
            </div>
          )}
        </div>

        <div className="flex-1 overflow-y-auto p-3 space-y-3">
          {isSelecting && allVisibleRecords.length > 0 && (
            <BulkSelectBar count={count} total={allVisibleRecords.length} allSelected={allSelected} onToggleAll={toggleSelectAll} onDeleteSelected={showTrash ? handleBulkPermanentDelete : handleBulkSoftDelete} />
          )}

          {groupedRecords.length === 0 && (
            <p className="text-xs text-slate-400 text-center py-10">
              {showTrash ? 'Recycle bin kosong.' : 'Belum ada riwayat input pada periode ini.'}
            </p>
          )}

          {groupedRecords.map(({ employee, records }) => {
            const empId = employee?.id || records[0]?.employeeId;
            // Set collapsedEmployees sekarang nyimpen ID yang lagi DIBUKA
            // (di-expand), jadi default-nya (Set kosong) = semua tertutup.
            const isCollapsed = !collapsedEmployees.has(empId);

            return (
              <div key={empId} className="border border-slate-200 rounded-xl overflow-hidden shadow-sm">
                <button onClick={() => toggleEmployeeCollapse(empId)} className="w-full flex items-center justify-between px-3 py-2.5 bg-slate-50 hover:bg-slate-100 transition-colors">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-full bg-slate-200 flex items-center justify-center shrink-0">
                      <User className="w-4 h-4 text-slate-500" />
                    </div>
                    <div className="text-left">
                      <p className="font-bold text-sm text-slate-800">{employee?.name || 'Tidak Dikenal'}</p>
                      <p className="text-[11px] text-slate-400">{records.length} record</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2.5 shrink-0">
                    {isCollapsed ? <ChevronRight className="w-4 h-4 text-slate-400" /> : <ChevronDown className="w-4 h-4 text-slate-400" />}
                  </div>
                </button>

                {!isCollapsed && (
                  <div className="divide-y divide-slate-100">
                    {records.map(rec => {
                      const isExpanded = expandedRecordId === rec.id;
                      const recDerivedKasbon = getDerivedKasbon(rec.employeeId, rec.dateStr);
                      const recTotalAdd = (rec.additions || []).reduce((s, a) => s + (a.amount || 0), 0);
                      const recTotalDed = (rec.deductions || []).reduce((s, d) => s + (d.amount || 0), 0) + recDerivedKasbon.reduce((s, d) => s + (d.amount || 0), 0);
                      const hasAdj = (rec.additions?.length || 0) + (rec.deductions?.length || 0) + recDerivedKasbon.length > 0;

                      return (
                        <div key={rec.id} className={`bg-white dark:bg-slate-900 ${selectedIds.has(rec.id) ? 'bg-accent-50/60 dark:bg-accent-500/5' : ''}`}>
                          <button
                            type="button"
                            onClick={() => setExpandedRecordId(isExpanded ? null : rec.id)}
                            className="w-full flex items-start justify-between gap-2 px-3 py-2.5 text-left hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors"
                          >
                            <div className="flex items-start gap-2 flex-1 min-w-0">
                              {isSelecting && (
                                <input type="checkbox" checked={selectedIds.has(rec.id)} onClick={e => e.stopPropagation()} onChange={() => toggleSelectOne(rec.id)} className="w-4 h-4 mt-0.5 rounded accent-[#ea580c] dark:accent-[#f97316] cursor-pointer shrink-0" />
                              )}
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center gap-2 flex-wrap">
                                  <span className="text-xs font-bold text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded-md font-mono">{rec.dateStr}</span>
                                  {rec.isDayOff ? (
                                    <>
                                      <Badge variant="neutral">Libur</Badge>
                                      {(rec.hoursWorked > 0 || rec.clockIn) && (
                                        // [+] Indikator anomali data LAMA: record ini kesimpen
                                        // isDayOff:true BERSAMAAN dengan jam kerja aktual — ini
                                        // gak mungkin terjadi lagi untuk record BARU sejak fix
                                        // prioritas hasMasuk (payrollLogic.js) & pembersihan
                                        // isDayOff (handleSaveEdit) diterapkan, tapi record LAMA
                                        // yang sudah kadung tersimpan sebelum fix ini gak
                                        // otomatis ter-refresh sampai attendanceLog-nya berubah
                                        // lagi. Klik Edit lalu simpan ulang jam masuk/keluar buat
                                        // membersihkannya.
                                        <Badge variant="warning" title="Data lama kontradiktif: tercatat Libur tapi ada jam kerja. Buka Edit untuk membersihkan.">
                                          ⚠️ Cek Data
                                        </Badge>
                                      )}
                                    </>
                                  ) : (
                                    <span className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-1">
                                      <Clock className="w-3 h-3" />
                                      {formatJam(rec.hoursWorked) ? `${formatJam(rec.hoursWorked)} jam` : 'Belum clock-out'}
                                    </span>
                                  )}
                                </div>
                                {hasAdj && (
                                  <div className="flex items-center gap-1.5 mt-1.5 flex-wrap">
                                    {recTotalAdd > 0 && <span className="text-[11px] font-semibold text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-500/10 border border-emerald-100 dark:border-emerald-500/20 px-1.5 py-0.5 rounded-lg">+{formatRupiah(recTotalAdd)}</span>}
                                    {recTotalDed > 0 && <span className="text-[11px] font-semibold text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-500/10 border border-red-100 dark:border-red-500/20 px-1.5 py-0.5 rounded-lg">-{formatRupiah(recTotalDed)}</span>}
                                  </div>
                                )}
                              </div>
                            </div>
                            <div className="flex items-center gap-1 shrink-0" onClick={e => e.stopPropagation()}>
                              {!showTrash && (
                                <IconButton variant="edit" onClick={() => handleOpenEdit(rec)} title="Edit Tambahan/Potongan"><Edit3 className="w-3.5 h-3.5" /></IconButton>
                              )}
                              <IconButton variant="delete" onClick={() => handleDeleteRecord(rec)} title={showTrash ? "Hapus Permanen" : "Hapus ke Recycle Bin"}>
                                <Trash2 className="w-3.5 h-3.5" />
                              </IconButton>
                              {isExpanded ? <ChevronDown className="w-4 h-4 text-slate-400 shrink-0" /> : <ChevronRight className="w-4 h-4 text-slate-400 shrink-0" />}
                            </div>
                          </button>

                          {isExpanded && (
                            <div className="px-3 pb-2.5 pt-2.5 border-t border-slate-100 animate-in fade-in duration-200">
                              {rec.isDayOff ? <p className="text-xs text-slate-400 text-center py-2">Tidak ada data absensi (Libur).</p> : (
                                <>
                                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 mb-3">
                                    <StatField label="Jam Masuk" value={rec.clockIn} />
                                    <StatField label="Jam Keluar" value={rec.clockOut} />
                                    <StatField label="Bolong (Jam)" value={!rec.bolongMinutes ? '0,0' : (rec.bolongMinutes / 60).toFixed(1).replace('.', ',')} />
                                    <StatField label="Lembur (Jam)" value={!rec.overtimeMinutes ? '0,0' : (rec.overtimeMinutes / 60).toFixed(1).replace('.', ',')} highlight={rec.overtimeMinutes > 0} />
                                    <StatField label="Uang Lembur" value={rec.overtimeMinutes > 0 ? formatRupiah(calculateOvertimePay(rec.overtimeMinutes, getOvertimeRate(resolveEmployeeForRecord(rec, employees)))) : '-'} highlight={rec.overtimeMinutes > 0} />
                                    <StatField label="Total Jam" value={formatJam(rec.hoursWorked) || '0,0'} highlight />
                                  </div>

                                  {hasAdj && (
                                    <div className="bg-slate-50 rounded-lg p-2.5">
                                      <p className="text-[11px] font-bold text-slate-500 mb-2">Rincian Tambahan / Potongan</p>
                                      <div className="space-y-1">
                                        {[...(rec.additions || []).map(a => ({ ...a, _type: 'addition' })), ...(rec.deductions || []).map(d => ({ ...d, _type: 'deduction' })), ...recDerivedKasbon].map(item => (
                                          <div key={item.id} className={`flex justify-between items-center text-[11px] px-2 py-1.5 rounded-md ${item._type === 'addition' ? 'bg-emerald-50 dark:bg-emerald-500/10 text-emerald-700 dark:text-emerald-400' : 'bg-red-50 dark:bg-red-500/10 text-red-600 dark:text-red-400'}`}>
                                            <span className="font-semibold truncate pr-2">{item.category}{item.isAuto ? ' (Otomatis)' : ''}{item.note ? ` · ${item.note}` : ''}</span>
                                            <span className="font-bold shrink-0">{item._type === 'addition' ? '+' : '-'}{formatRupiah(item.amount)}</span>
                                          </div>
                                        ))}
                                      </div>
                                    </div>
                                  )}
                                </>
                              )}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </Card>

      {/* ════════════════════════════════════════ */}
      {/* MODAL EDIT TAMBAHAN & POTONGAN           */}
      {/* ════════════════════════════════════════ */}
      {editingRecord && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md max-h-[90vh] flex flex-col animate-in zoom-in-95 fade-in duration-200">
            <div className="flex items-center justify-between p-4 border-b border-slate-100">
              <div>
                <h3 className="font-heading font-bold text-slate-800">{editingEmpName}</h3>
                <p className="text-xs text-slate-400 mt-0.5">{editingRecord.dateStr} · Edit Rincian Harian</p>
              </div>
              <button onClick={handleCloseEdit} className="p-2 rounded-lg hover:bg-slate-100 transition-colors text-slate-400 hover:text-slate-700"><X className="w-5 h-5" /></button>
            </div>
            
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              <div className="grid grid-cols-2 gap-3 pb-1 border-b border-slate-100">
                <Input 
                  type="time" 
                  label="Jam Masuk" 
                  variant="muted" 
                  value={editClockIn} 
                  onChange={e => setEditClockIn(e.target.value)} 
                />
                <Input 
                  type="time" 
                  label="Jam Keluar" 
                  variant="muted" 
                  value={editClockOut} 
                  onChange={e => setEditClockOut(e.target.value)} 
                />
              </div>
              {editingRecord.bolongMinutes > 0 && (
                // [+] Hint kondisional: cuma muncul kalau record ini punya durasi
                // bolong tercatat (bolongMinutes > 0). Mengedit Jam Masuk/Keluar
                // di sini SAJA gak cukup kalau karyawan sebenarnya balik kerja
                // setelah bolong — bolongMinutes dihitung ulang dari
                // attendanceLog mentah (lihat handleSaveEdit), dan tanpa record
                // 'masuk_lagi' yang cocok, seluruh rentang dari mulai bolong
                // sampai Jam Keluar baru tetap dianggap bolong utuh, bukan jam
                // kerja.
                <p className="text-[11px] text-amber-700 bg-amber-50 border border-amber-200 rounded-lg px-2.5 py-2 mb-3">
                  ⚠️ Karyawan ini punya jam bolong tercatat. Ubah Jam Masuk/Keluar di sini akan menghitung ulang durasi bolongnya secara otomatis.
                  Kalau karyawan sebenarnya <span className="font-semibold">sudah balik kerja</span> setelah bolong, tambahkan juga record "Masuk Lagi" di jam yang sesuai lewat menu Absensi Karyawan — kalau tidak, seluruh rentang sejak mulai bolong sampai Jam Keluar akan tetap dihitung sebagai bolong, bukan jam kerja.
                </p>
              )}

              <SegmentedControl options={[{ value: 'addition', label: 'Penghasilan (+)', tone: 'green' }, { value: 'deduction', label: 'Potongan (-)', tone: 'red' }]} value={editAdjType} onChange={(val) => { setEditAdjType(val); setEditAdjCategory(''); }} />
              <div>
                <label className="text-xs font-bold text-slate-500 mb-1.5 block">Kategori</label>
                <Select variant="muted" value={editAdjCategory} onChange={e => setEditAdjCategory(e.target.value)}>
                  <option value="">Pilih Kategori</option>
                  {editAdjType === 'addition'
                    ? [...new Set(additionCategories)].filter(c => !c.toLowerCase().includes(LEMBUR_CATEGORY_KEYWORD)).map(c => <option key={c} value={c}>{c}</option>)
                    : [...new Set(deductionCategories)].filter(c => !c.toLowerCase().includes(KASBON_CATEGORY_KEYWORD)).map(c => <option key={c} value={c}>{c}</option>)
                  }
                </Select>
              </div>
              <Input type="number" label="Nominal" variant="muted" icon={<span>Rp</span>} value={editAdjAmount} onChange={e => setEditAdjAmount(e.target.value)} />
              <Input label="Catatan" variant="muted" value={editAdjNote} onChange={e => setEditAdjNote(e.target.value)} />
              {editAdjType === 'deduction' && (
                <div>
                  <label className="text-xs font-bold text-slate-500 mb-1.5 block">Metode Pembayaran</label>
                  <SegmentedControl options={[{ value: 'Tunai', label: 'Tunai' }, { value: 'Non-Tunai', label: 'Non-Tunai' }]} value={editAdjPaymentMethod} onChange={setEditAdjPaymentMethod} />
                </div>
              )}
              <Button variant={editAdjType === 'addition' ? 'success' : 'danger'} size="full" icon={<Plus className="w-4 h-4" />} onClick={handleEditAddAdjustment}>
                {editAdjType === 'addition' ? 'Tambah Penghasilan' : 'Tambah Potongan'}
              </Button>
              <div className="pt-3 border-t border-slate-100">
                <p className="text-xs font-bold text-slate-500 mb-2">Rincian Saat Ini</p>
                {editAdjRows.length === 0 ? <p className="text-xs text-slate-400 text-center py-3">Belum ada tambahan/potongan.</p> : <div className="space-y-2">{editAdjRows.map(item => <AdjRow key={item.id} item={item} onRemove={handleEditRemoveAdjustment} formatRupiah={formatRupiah} />)}</div>}
              </div>
              {editAdjRows.length > 0 && (
                <div className="space-y-1 pt-3 border-t border-slate-100 text-xs">
                  <div className="flex justify-between text-slate-500"><span>Total Tambahan</span><span className="font-bold text-emerald-700 dark:text-emerald-400">+{formatRupiah(editTotalAdditions)}</span></div>
                  <div className="flex justify-between text-slate-500"><span>Total Potongan</span><span className="font-bold text-red-700">-{formatRupiah(editTotalDeductions)}</span></div>
                  <div className="flex justify-between font-bold text-slate-800 pt-1.5 border-t border-slate-100"><span>Net</span><span>{editNetAdjustment >= 0 ? '+' : ''}{formatRupiah(editNetAdjustment)}</span></div>
                </div>
              )}
            </div>
            
            <div className="p-4 border-t border-slate-100 flex gap-2">
              <Button variant="secondary" size="full" onClick={handleCloseEdit}>Batal</Button>
              <Button variant="primary" size="full" icon={<Save className="w-4 h-4" />} onClick={handleSaveEdit}>Simpan Perubahan</Button>
            </div>
          </div>
        </div>
      )}

      <SortModal isOpen={isDailySortOpen} onClose={() => setIsDailySortOpen(false)} value={dailySortKey} onChange={setDailySortKey} options={[{ key: 'date-desc', label: 'Terbaru Dulu' }, { key: 'name-asc', label: 'Nama (A-Z)' }]} />
      <CategoryModal isOpen={catModalType === 'addition'} onClose={() => setCatModalType(null)} title="Kategori Penghasilan" categories={additionCategories} setCategories={setAdditionCategories} triggerAlert={triggerAlert} triggerConfirm={triggerConfirm} onDeleteFallback={'Lainnya'} />
      <CategoryModal isOpen={catModalType === 'deduction'} onClose={() => setCatModalType(null)} title="Kategori Potongan" categories={deductionCategories} setCategories={setDeductionCategories} triggerAlert={triggerAlert} triggerConfirm={triggerConfirm} onDeleteFallback={'Lainnya'} />
    </div>
  );
};

export default InputDailyTab;
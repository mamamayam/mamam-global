import React, { useState, useMemo, useEffect, createContext, useContext, useRef, useCallback } from 'react';
import { App as CapacitorApp } from '@capacitor/app';
import { usePersistState } from '../hook/usePersistState';
import { useOnlineStatus } from '../hook/useOnlineStatus';
import { INITIAL_MENUS, INITIAL_VARIANT_GROUPS, INITIAL_CATEGORIES, INITIAL_RAW_MATERIALS } from '../data/initialData';
import { AppContext, useAppContext } from '../context/AppContext';
import { usePosStore } from '../store/usePosStore';
import { Modal, Button } from '../components/ui';
import PinModal from '../auth/PinModal';
import AppRoutes from '../app/AppRoutes';
import AppLayout from '../app/AppLayout';
import Sidebar from '../app/layout/Sidebar';
import Header from '../app/layout/Header';
import BottomNav from '../app/layout/BottomNav';
import ReceiptModal from '../features/pos/ReceiptModal';

import {
  AlertCircle,
  Briefcase,
  Calculator,
  Calendar,
  CheckCircle2,
  TrendingDown,
  Clock,
  Coffee,
  Copy,
  CreditCard,
  DollarSign,
  Download,
  Edit3,
  FileText,
  Fingerprint,
  History,
  Home,
  Info,
  Layers,
  List,
  Menu as MenuIcon,
  Minus,
  MoreHorizontal,
  Motorbike,
  Package,
  Pencil,
  PieChart,
  Plus,
  Printer,
  QrCode,
  Receipt,
  RefreshCw,
  Save,
  Search,
  Settings,
  ShoppingCart,
  SplitSquareHorizontal,
  Store,
  Ticket,
  Trash2,
  TrendingUp,
  Truck,
  UserCog,
  Users,
  UtensilsCrossed,
  Wallet,
  X,
  Warehouse,
  BarChart3,
  Wifi,
  WifiOff,
} from 'lucide-react';

// Interval auto-sync berkala (lihat useEffect di bawah). 10 menit — cukup
// sering buat nangkep perubahan config selama jam kerja, tapi murah karena
// runAutoSync cuma push kalau BENERAN ada yang beda (gak ada network call
// kalau nggak ada perubahan).
const AUTO_SYNC_INTERVAL_MS = 10 * 60 * 1000;




export default function App() {


  // --- BACK NAVIGATION ---
  const [viewHistory, setViewHistory] = useState([]);
  const [showExitToast, setShowExitToast] = useState(false);
  const lastBackPressRef = useRef(null);
  const exitToastTimerRef = useRef(null);
  const [showExitConfirm, setShowExitConfirm] = useState(false);

  const [variantCategories, setVariantCategories] = useState(['Lainnya']);

  // --- TOAST KONEKSI ONLINE/OFFLINE ---
  const { isOnline, justWentOnline, justWentOffline, clearTransition } = useOnlineStatus();
  const [connectionToast, setConnectionToast] = useState(null); // { msg, type: 'offline'|'syncing'|'online' }
  const connectionToastTimerRef = useRef(null);


  const [isAdminMode, setIsAdminMode] = useState(false);
  const [showPinModal, setShowPinModal] = useState(false);

  const handleAdminLogin = () => {
    setIsAdminMode(true);
  };

  const [currentView, setCurrentView] = useState('kasir');
  const [activeTab, setActiveTab] = useState('materials');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  // --- FUNGSI NAVIGASI DENGAN HISTORY STACK ---
  // Root views = tab utama; navigasi ke sini me-reset history
  const ROOT_VIEWS = useMemo(() => new Set(['beranda', 'kasir', 'pengaturan']), []);

  // Tampilkan toast "ketuk sekali lagi" dan handle double-tap exit
  const handleExitAttempt = useCallback(() => {
    const now = Date.now();
    if (lastBackPressRef.current && now - lastBackPressRef.current < 2000) {
      // Tekan kedua dalam 2 detik → keluar aplikasi
      CapacitorApp.exitApp();
    } else {
      // Tekan pertama → tampilkan toast
      lastBackPressRef.current = now;
      setShowExitToast(true);
      clearTimeout(exitToastTimerRef.current);
      exitToastTimerRef.current = setTimeout(() => {
        setShowExitToast(false);
        lastBackPressRef.current = null;
      }, 2000);
    }
  }, []);

  // navigate(view) → push ke history stack, lalu pindah view
  const navigate = useCallback((view) => {
    if (view === currentView) return;
    if (ROOT_VIEWS.has(view)) {
      // Navigasi ke root → reset stack
      setViewHistory([]);
    } else {
      // Navigasi ke sub-halaman → simpan halaman saat ini ke stack
      setViewHistory(prev => [...prev, currentView]);
    }
    setCurrentView(view);
  }, [currentView, ROOT_VIEWS]);

  // navigateBack() → dipanggil saat tombol back ditekan
  const navigateBack = useCallback(() => {
    if (viewHistory.length > 0) {
      // Ada history → kembali ke view sebelumnya
      const prev = viewHistory[viewHistory.length - 1];
      setViewHistory(h => h.slice(0, -1));
      setCurrentView(prev);
    } else if (currentView !== 'beranda') {
      // Tidak ada history, bukan beranda → ke beranda
      setCurrentView('beranda');
    } else {
      // Di beranda tanpa history → double-tap exit
      handleExitAttempt();
    }
  }, [viewHistory, currentView, handleExitAttempt]);

  // ── Sync status (dipakai untuk UI blocking saat startup) ────────────────
  // 'idle'     = Supabase tidak dikonfigurasi, langsung masuk app
  // 'syncing'  = sedang initial pull dari Supabase (semua push diblok)
  // 'ready'    = pull selesai, push diizinkan, realtime aktif
  // 'error'    = pull gagal, masuk app dengan data lokal
  // Kalau Supabase dikonfigurasi, langsung mulai dengan 'syncing' supaya
  // overlay muncul SEGERA tanpa gap antara allDataLoaded dan async IIFE
  const [syncStatus, setSyncStatus] = useState(() => {
    const url = import.meta.env?.VITE_SUPABASE_URL;
    const key = import.meta.env?.VITE_SUPABASE_ANON_KEY;
    return (url && key) ? 'syncing' : 'idle';
  });
  const [syncStep, setSyncStep] = useState('Menghubungkan ke server...');

  const cleanupRef = useRef(null);

  const syncGateRef = useRef(null);
  if (!syncGateRef.current) {
    let resolveSync;
    const promise = new Promise(r => { resolveSync = r; });
    syncGateRef.current = { promise, resolveSync };
  }
  const syncReadyPromise = syncGateRef.current.promise;

  const [variantGroups, setVariantGroups, l1, setVariantGroupsRemote] = usePersistState('variantGroups', INITIAL_VARIANT_GROUPS, { syncMode: 'config', syncReadyPromise });
  const [menus, setMenus, l2, setMenusRemote] = usePersistState('menus', INITIAL_MENUS, { syncMode: 'config', syncReadyPromise });
  const [salesHistory, setSalesHistory, l3, setSalesHistoryRemote] = usePersistState('salesHistory', [], { syncMode: 'transaction', syncReadyPromise });
  const [hppLibrary, setHppLibrary, l4, setHppLibraryRemote] = usePersistState('hppLibrary', [], { syncMode: 'config', syncReadyPromise });
  const [savedBills, setSavedBills, l5, setSavedBillsRemote] = usePersistState('savedBills', [], { syncMode: 'transaction', syncReadyPromise });

  // --- HPP & BAHAN BAKU ---
  const [rawMaterials, setRawMaterials, l6, setRawMaterialsRemote] = usePersistState('rawMaterials', INITIAL_RAW_MATERIALS, { syncMode: 'config', syncReadyPromise });
  const [semiFinished, setSemiFinished, l7, setSemiFinishedRemote] = usePersistState('semiFinished', [], { syncMode: 'config', syncReadyPromise });
  const [categories, setCategories, l8, setCategoriesRemote] = usePersistState('categories', INITIAL_CATEGORIES, { syncMode: 'config', syncReadyPromise });
  const [editingRecipe, setEditingRecipe] = useState(null);

  // --- KEUANGAN ---
  const [expenseCategories, setExpenseCategories, l9, setExpenseCategoriesRemote] = usePersistState('expenseCategories', ['Belanja', 'Biaya', 'Kasbon Karyawan', 'Lain-lain'], { syncMode: 'config', syncReadyPromise });
  const [expenses, setExpenses, l10, setExpensesRemote] = usePersistState('expenses', [], { syncMode: 'transaction', syncReadyPromise });
  const [incomeCategories, setIncomeCategories, l11, setIncomeCategoriesRemote] = usePersistState('incomeCategories', ['Modal Tambahan', 'Pendapatan Lain', 'Titipan Uang'], { syncMode: 'config', syncReadyPromise });
  const [incomes, setIncomes, l12, setIncomesRemote] = usePersistState('incomes', [], { syncMode: 'transaction', syncReadyPromise });

  // --- SHIFT ---
  const [currentShift, setCurrentShift, l13, setCurrentShiftRemote] = usePersistState('currentShift', null, { syncMode: 'live', syncReadyPromise });
  const [shiftHistory, setShiftHistory, l14, setShiftHistoryRemote] = usePersistState('shiftHistory', [], { syncMode: 'transaction', syncReadyPromise });

  // --- PELANGGAN ----
  const [customers, setCustomers, l15, setCustomersRemote] = usePersistState('customers', [], { syncMode: 'transaction', syncReadyPromise });
  const [vouchers, setVouchers, l16, setVouchersRemote] = usePersistState('vouchers', [], { syncMode: 'config', syncReadyPromise });
  const [claimsHistory, setClaimsHistory, l17, setClaimsHistoryRemote] = usePersistState('claimsHistory', [], { syncMode: 'transaction', syncReadyPromise });

  // --- PAYROLL STATES ---
  const [employees, setEmployees, l18, setEmployeesRemote] = usePersistState('employees', [], { syncMode: 'config', syncReadyPromise });
  const [employeeDailyRecords, setEmployeeDailyRecords, l19, setEmployeeDailyRecordsRemote] = usePersistState('employeeDailyRecords', [], { syncMode: 'transaction', syncReadyPromise });
  const [attendanceLog, setAttendanceLog, l24, setAttendanceLogRemote] = usePersistState('attendanceLog', [], { syncMode: 'transaction', syncReadyPromise });
  const [additionCategories, setAdditionCategories, l20, setAdditionCategoriesRemote] = usePersistState('additionCategories', ['Ongkir', 'Lembur', 'Bonus', 'Potongin Ayam'], { syncMode: 'config', syncReadyPromise });
  const [deductionCategories, setDeductionCategories, l21, setDeductionCategoriesRemote] = usePersistState('deductionCategories', ['Kasbon', 'Denda', 'Ganti Rugi'], { syncMode: 'config', syncReadyPromise });

  // --- SETTINGS ---
  const [storeSettings, setStoreSettings, l22, setStoreSettingsRemote] = usePersistState('storeSettings', {
    autoPrint: false, paperSize: '58mm', printLogo: true, taxRate: 0, serviceCharge: 0
  }, { syncMode: 'config', syncReadyPromise });

  const [theme, setTheme, l23] = usePersistState('theme', 'light');
  const [colorTheme, setColorThemeState] = usePersistState('colorTheme', 'orange');

  useEffect(() => {
    document.documentElement.setAttribute('data-color-theme', colorTheme);
  }, [colorTheme]);

  const setColorTheme = (newTheme) => {
    setColorThemeState(newTheme);
  };

  // Terapkan class .dark ke <html> setiap kali tema berubah
  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [theme]);

  // Semua data dari Dexie sudah selesai dimuat?
  const allDataLoaded = ![l1, l2, l3, l4, l5, l6, l7, l8, l9, l10, l11, l12, l13, l14, l15, l16, l17, l18, l19, l20, l21, l22, l24].some(Boolean);

  // ── Map setter remote — dipakai oleh realtime callback ──────────────────
  const remoteSetterMap = useRef({});
  useEffect(() => {
    remoteSetterMap.current = {
      variantGroups: setVariantGroupsRemote,
      menus: setMenusRemote,
      salesHistory: setSalesHistoryRemote,
      hppLibrary: setHppLibraryRemote,
      savedBills: setSavedBillsRemote,
      rawMaterials: setRawMaterialsRemote,
      semiFinished: setSemiFinishedRemote,
      categories: setCategoriesRemote,
      expenseCategories: setExpenseCategoriesRemote,
      expenses: setExpensesRemote,
      incomeCategories: setIncomeCategoriesRemote,
      incomes: setIncomesRemote,
      currentShift: setCurrentShiftRemote,
      shiftHistory: setShiftHistoryRemote,
      customers: setCustomersRemote,
      vouchers: setVouchersRemote,
      claimsHistory: setClaimsHistoryRemote,
      employees: setEmployeesRemote,
      employeeDailyRecords: setEmployeeDailyRecordsRemote,
      attendanceLog: setAttendanceLogRemote,
      additionCategories: setAdditionCategoriesRemote,
      deductionCategories: setDeductionCategoriesRemote,
      storeSettings: setStoreSettingsRemote,
    };
  });

  // ── Inisialisasi Realtime Sync — jalankan SETELAH Dexie selesai dimuat ──
  // Urutan wajib: (1) connect → (2) initial pull server → (3) merge lokal
  // → (4) simpan → (5) resolve syncReadyPromise → (6) push diizinkan
  useEffect(() => {
    if (!allDataLoaded) return;

    let cancelled = false;

    // Fallback timeout 15 detik — kalau Supabase stuck, buka app dengan data lokal
    const timeoutId = setTimeout(() => {
      if (cancelled) return;
      console.warn('[App] Sync timeout 15s — masuk dengan data lokal');
      syncGateRef.current.resolveSync?.();
      setSyncStatus('error');
      setSyncStep('');
    }, 15000);

    (async () => {
      // Dynamic import agar tidak error saat modul tidak tersedia
      let isSupabaseConfigured, initRealtimeSync;
      try {
        ({ isSupabaseConfigured } = await import('../storage/syncClient'));
        ({ initRealtimeSync } = await import('../storage/realtimeSync'));
      } catch (e) {
        syncGateRef.current.resolveSync?.();
        return;
      }

      // Jika Supabase tidak dikonfigurasi, langsung resolve supaya push tidak diblok
      if (!isSupabaseConfigured()) {
        syncGateRef.current.resolveSync?.();
        return;
      }

      if (cancelled) return;

      // syncStatus sudah 'syncing' dari initial state — tidak perlu set ulang
      setSyncStep('Mengambil data dari server...');

      const { unsubscribe, syncReadyPromise: enginePromise } = initRealtimeSync({
        // Dipanggil saat initial pull SELESAI untuk satu tableKey (transaksi)
        // atau saat realtime event datang dari device lain.
        // `fullArray` = array penuh hasil merge (initial pull); `item` = satu record (realtime)
        onTransactionUpsert: (tableKey, item, fullArray) => {
          const setter = remoteSetterMap.current[tableKey];
          if (!setter) return;
          if (fullArray) {
            // Initial pull → set langsung array penuh hasil merge
            setter(fullArray);
          } else if (item) {
            // Realtime event → upsert satu item ke dalam state
            setter(prev => {
              const arr = Array.isArray(prev) ? prev : [];
              const idx = arr.findIndex(e => String(e.id) === String(item.id));
              return idx >= 0 ? arr.map((e, i) => i === idx ? item : e) : [...arr, item];
            });
          }
        },
        onTransactionDelete: (tableKey, id) => {
          const setter = remoteSetterMap.current[tableKey];
          if (!setter) return;
          setter(prev => (Array.isArray(prev) ? prev : []).filter(e => String(e.id) !== String(id)));
        },
        onConfigUpdate: (key, value) => {
          const setter = remoteSetterMap.current[key];
          if (setter) setter(value);
        },
      });

      enginePromise.then(() => {
        if (cancelled) return;
        clearTimeout(timeoutId);
        syncGateRef.current.resolveSync?.();
        setSyncStatus('ready');
        setSyncStep('');
        console.log('[App] Sinkronisasi awal selesai ✅ — push diizinkan');

        // Catch-up otomatis begitu app kebuka: kalo sesi sebelumnya ketutup
        // sebelum sempat sync (config/transaksi numpuk), langsung coba kirim
        // SEKARANG — gak nunggu user pencet manual atau nunggu jam tertentu.
        (async () => {
          try {
            const { runAutoSync } = await import('../storage/realtimeSync');
            const { sent, failed } = await runAutoSync({ force: true });
            if (sent > 0 || failed > 0) {
              console.log(`[App] Catch-up sync startup: ${sent} terkirim, ${failed} gagal`);
            }
          } catch (e) {
            console.warn('[App] Catch-up sync startup error:', e?.message);
          }
        })();
      }).catch((err) => {
        if (cancelled) return;
        clearTimeout(timeoutId);
        console.warn('[App] Sync awal gagal, masuk dengan data lokal:', err?.message);
        syncGateRef.current.resolveSync?.();
        setSyncStatus('error');
        setSyncStep('');
      });

      // Simpan unsubscribe ke ref agar bisa dipanggil saat cleanup
      cleanupRef.current = unsubscribe;
    })();
    return () => {
      cancelled = true;
      clearTimeout(timeoutId);
      cleanupRef.current?.();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [allDataLoaded]);

  // ── Toast koneksi: reaksi ke transisi online/offline ────────────────────
  // - Baru mati → toast "Mode Offline", nempel sampai online lagi (gak auto-hide).
  // - Baru nyala → toast "Menyinkronkan ulang..." lalu trigger runAutoSync
  //   force, baru toast "Tersinkronisasi" dan auto-hide.
  useEffect(() => {
    if (justWentOffline) {
      clearTimeout(connectionToastTimerRef.current);
      setConnectionToast({ msg: 'Mode Offline — perubahan disimpan lokal', type: 'offline' });
      clearTransition();
      return;
    }

    if (justWentOnline) {
      clearTimeout(connectionToastTimerRef.current);
      setConnectionToast({ msg: 'Online — menyinkronkan ulang...', type: 'syncing' });
      clearTransition();

      (async () => {
        try {
          const { isSupabaseConfigured } = await import('../storage/syncClient');
          if (!isSupabaseConfigured()) {
            setConnectionToast(null);
            return;
          }
          const { runAutoSync } = await import('../storage/realtimeSync');
          const { sent, failed } = await runAutoSync({ force: true });
          setConnectionToast({
            msg: failed > 0
              ? `Tersinkronisasi sebagian — ${sent} terkirim, ${failed} gagal`
              : sent > 0 ? `Tersinkronisasi — ${sent} perubahan terkirim` : 'Tersinkronisasi ✓',
            type: 'online',
          });
        } catch (e) {
          setConnectionToast({ msg: 'Online, tapi sync gagal — coba manual sync', type: 'online' });
        } finally {
          connectionToastTimerRef.current = setTimeout(() => setConnectionToast(null), 3500);
        }
      })();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [justWentOffline, justWentOnline]);

  useEffect(() => () => clearTimeout(connectionToastTimerRef.current), []);

  // ── Auto-sync berkala — GANTI cara lama (cek jam 21:00 yang cuma jalan
  // kalau layar BackupView lagi kebuka). Ini jalan di level App.jsx, tiap
  // AUTO_SYNC_INTERVAL_MS, SELAMA app kebuka — gak peduli user lagi di layar
  // mana. force:false aman dipanggil berkali-kali (lihat komen runAutoSync
  // di storage/realtimeSync.js soal kenapa itu gak akan bulk-upload key yang
  // belum pernah ke-baseline).
  const syncStatusRef = useRef(syncStatus);
  useEffect(() => { syncStatusRef.current = syncStatus; }, [syncStatus]);

  useEffect(() => {
    if (syncStatus !== 'ready' && syncStatus !== 'error') return;

    const id = setInterval(async () => {
      try {
        const { isAutoSyncEnabled, runAutoSync } = await import('../storage/realtimeSync');
        if (!isAutoSyncEnabled()) return;
        const { sent, failed } = await runAutoSync({ force: false });
        if (sent > 0) console.log(`[App] Auto-sync berkala: ${sent} terkirim`);
        if (failed > 0) console.warn(`[App] Auto-sync berkala: ${failed} gagal, dicoba lagi nanti`);
      } catch (e) {
        console.warn('[App] Auto-sync berkala error:', e?.message);
      }
    }, AUTO_SYNC_INTERVAL_MS);

    return () => clearInterval(id);
  }, [syncStatus]);

  // ── Flush pas app di-background / dibuka lagi ───────────────────────────
  // Best-effort: begitu app diminimize/dikunci (karyawan pulang & HP
  // ditinggal, dll), coba kirim sisa perubahan SEBELUM device idle. Juga
  // coba lagi pas app dibuka balik, sebagai jaring pengaman ekstra selain
  // auto-sync berkala di atas.
  // CATATAN JUJUR: OS/browser bisa langsung suspend eksekusi JS begitu app
  // di-background — ini best-effort, BUKAN jaminan 100%. Auto-sync berkala
  // di atas tetap jalur paling reliable karena jalan selama app aktif.
  useEffect(() => {
    let lastFlush = 0;
    const FLUSH_COOLDOWN_MS = 5000; // cegah dobel-trigger kalo pause & visibilitychange nembak bareng

    const flush = async (label) => {
      if (syncStatusRef.current !== 'ready' && syncStatusRef.current !== 'error') return;
      const now = Date.now();
      if (now - lastFlush < FLUSH_COOLDOWN_MS) return;
      lastFlush = now;
      try {
        const { runAutoSync } = await import('../storage/realtimeSync');
        const { sent, failed } = await runAutoSync({ force: true });
        console.log(`[App] Flush (${label}): ${sent} terkirim, ${failed} gagal`);
      } catch (e) {
        console.warn(`[App] Flush (${label}) error:`, e?.message);
      }
    };

    const handleVisibility = () => {
      if (document.visibilityState === 'hidden') flush('visibility-hidden');
      else if (document.visibilityState === 'visible') flush('visibility-visible');
    };
    document.addEventListener('visibilitychange', handleVisibility);

    let pauseHandle, resumeHandle;
    (async () => {
      pauseHandle = await CapacitorApp.addListener('pause', () => flush('capacitor-pause'));
      resumeHandle = await CapacitorApp.addListener('resume', () => flush('capacitor-resume'));
    })();

    return () => {
      document.removeEventListener('visibilitychange', handleVisibility);
      pauseHandle?.remove?.();
      resumeHandle?.remove?.();
    };
  }, []);

  // --- STATES APLIKASI ---
  const [appliedVoucher, setAppliedVoucher] = useState(null);
  const [voucherInputCode, setVoucherInputCode] = useState('');

  const getBulanIniStart = () => {
    const d = new Date();
    return new Date(d.getFullYear(), d.getMonth(), d.getDate() - 29).toISOString().split('T')[0];
  };
  const [reportDateRange, setReportDateRange] = useState({ start: getBulanIniStart(), end: new Date().toISOString().split('T')[0] });
  const [activePreset, setActivePreset] = useState('bulan_ini');

  const searchQuery = usePosStore((state) => state.searchQuery);
  const setSearchQuery = usePosStore((state) => state.setSearchQuery);
  const selectedCategory = usePosStore((state) => state.selectedCategory);
  const setSelectedCategory = usePosStore((state) => state.setSelectedCategory);
  const selectedMenuForVariant = usePosStore((state) => state.selectedMenuForVariant);
  const setSelectedMenuForVariant = usePosStore((state) => state.setSelectedMenuForVariant);
  const cart = usePosStore((state) => state.cart);
  const setCart = usePosStore((state) => state.setCart);
  const isCartOpen = usePosStore((state) => state.isCartOpen);
  const setIsCartOpen = usePosStore((state) => state.setIsCartOpen);
  const variantSelectedOptions = usePosStore((state) => state.variantSelectedOptions);
  const setVariantSelectedOptions = usePosStore((state) => state.setVariantSelectedOptions);
  const editingCartItemId = usePosStore((state) => state.editingCartItemId);
  const setEditingCartItemId = usePosStore((state) => state.setEditingCartItemId);
  const isCategoryModalOpen = usePosStore((state) => state.isCategoryModalOpen);
  const setIsCategoryModalOpen = usePosStore((state) => state.setIsCategoryModalOpen);
  const customerName = usePosStore((state) => state.customerName);
  const setCustomerName = usePosStore((state) => state.setCustomerName);
  const selectedCustomerId = usePosStore((state) => state.selectedCustomerId);
  const setSelectedCustomerId = usePosStore((state) => state.setSelectedCustomerId);
  const orderType = usePosStore((state) => state.orderType);
  const setOrderType = usePosStore((state) => state.setOrderType);
  const deliveryFee = usePosStore((state) => state.deliveryFee);
  const setDeliveryFee = usePosStore((state) => state.setDeliveryFee);
  const customDeliveryFee = usePosStore((state) => state.customDeliveryFee);
  const setCustomDeliveryFee = usePosStore((state) => state.setCustomDeliveryFee);
  const manualDiscount = usePosStore((state) => state.manualDiscount);
  const setManualDiscount = usePosStore((state) => state.setManualDiscount);
  const pointsToRedeem = usePosStore((state) => state.pointsToRedeem);
  const setPointsToRedeem = usePosStore((state) => state.setPointsToRedeem);
  const resetDraft = usePosStore((state) => state.resetDraft);

  const [paymentModal, setPaymentModal] = useState({ isOpen: false, isSplitMode: false, splitPayments: [], method: 'Tunai', amountPaid: '', status: 'pending', ojolName: '', orderNumber: '' });
  const [receiptModal, setReceiptModal] = useState({ isOpen: false, data: null });
  const [customAlert, setCustomAlert] = useState({ isOpen: false, message: '' });
  const [confirmModal, setConfirmModal] = useState({ isOpen: false, message: '', onConfirm: null });

  const [payslipModal, setPayslipModal] = useState({ isOpen: false, data: null, month: '' });

  const today = new Date().toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
  const formatRupiah = (number) => new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(number || 0);

  // Fix: activeCustomer sekarang ID-based, BUKAN name-matching lagi.
  // Alasan: cocokin nama pakai string (walau udah .toLowerCase()) tetap rapuh
  // terhadap spasi nyempil di data lama & gak bisa nentuin customer yang mana
  // kalau ada 2 nama persis sama. ID gak pernah ambigu.
  const activeCustomer = useMemo(() => {
    if (!selectedCustomerId) return null;
    return customers.find(c => c.id === selectedCustomerId) || null;
  }, [selectedCustomerId, customers]);

  useEffect(() => {
    if (!activeCustomer || cart.length === 0) setPointsToRedeem(0);
  }, [activeCustomer, cart.length]);

  const getSubtotal = () => cart.reduce((sum, item) => sum + (item.price * item.qty), 0);

  const getDiscount = () => {
    if (!appliedVoucher) return 0;
    const subtotal = getSubtotal();
    if (subtotal < appliedVoucher.minPurchase) return 0;
    if (appliedVoucher.discountType === 'percent') return subtotal * (appliedVoucher.discountValue / 100);
    return appliedVoucher.discountValue;
  };

  const getPointDiscount = () => pointsToRedeem * 100;

  const getManualDiscountAmount = () => {
    if (!manualDiscount || !manualDiscount.value) return 0;
    if (manualDiscount.type === 'percent') return (getSubtotal() * manualDiscount.value) / 100;
    return manualDiscount.value;
  };

  const getTaxableAmount = () => Math.max(0, getSubtotal() - getDiscount() - getPointDiscount() - getManualDiscountAmount());
  const getTaxAmount = () => getTaxableAmount() * (storeSettings.taxRate / 100);
  const getServiceChargeAmount = () => getTaxableAmount() * (storeSettings.serviceCharge / 100);

  const getTotal = () => Math.max(0, getTaxableAmount() + getTaxAmount() + getServiceChargeAmount() + (orderType === 'Delivery' ? deliveryFee : 0));

  const getRoundedTotal = () => {
    const originalTotal = getTotal();

    switch (storeSettings?.roundingMode) {
      case '500':
        return Math.floor(originalTotal / 500) * 500;

      default:
        return originalTotal;
    }
  };

  const getRoundingAdjustment = () => {
    return getRoundedTotal() - getTotal();
  };

  const triggerAlert = (message) => setCustomAlert({ isOpen: true, message });
  const triggerConfirm = (message, onConfirm) => setConfirmModal({ isOpen: true, message, onConfirm });

  const applyDatePreset = (preset) => {
    const todayStr = new Date().toISOString().split('T')[0];
    const d = new Date();
    setActivePreset(preset);

    if (preset === 'hari_ini') setReportDateRange({ start: todayStr, end: todayStr });
    else if (preset === 'minggu_ini') setReportDateRange({ start: new Date(d.getFullYear(), d.getMonth(), d.getDate() - 6).toISOString().split('T')[0], end: todayStr });
    else if (preset === 'bulan_ini') setReportDateRange({ start: new Date(d.getFullYear(), d.getMonth(), d.getDate() - 29).toISOString().split('T')[0], end: todayStr });
    else if (preset === 'bulan_berjalan') setReportDateRange({ start: new Date(d.getFullYear(), d.getMonth(), 1).toISOString().split('T')[0], end: todayStr });
  };

  const updateCartItemVariants = (oldCartItemId, newVariants) => {
    setCart(cart.map(item => {
      if (item.cartItemId === oldCartItemId) {
        let extraPriceTotal = 0, variantNames = [], selectedVariantDetails = [];

        Object.entries(newVariants).forEach(([groupId, optionIds]) => {
          const group = variantGroups.find(g => g.id === groupId);
          if (group) {
            optionIds.forEach(optId => {
              const opt = group.options.find(o => o.id === optId);
              if (opt) { extraPriceTotal += opt.extraPrice; variantNames.push(opt.name); selectedVariantDetails.push({ optionId: opt.id }); }
            });
          }
        });

        const menu = menus.find(m => m.id === item.menuId);
        const basePrice = menu ? menu.price : 0;
        const newVariantNameStr = variantNames.join(', ');
        const optionKeys = selectedVariantDetails.map(v => v.optionId).sort().join('-');
        const newCartItemId = optionKeys ? `${item.menuId}-${optionKeys}` : item.menuId;

        return {
          ...item,
          cartItemId: newCartItemId,
          variantName: newVariantNameStr,
          price: basePrice + extraPriceTotal,
          variantSelectedOptions: newVariants
        };
      }
      return item;
    }));
  };

  const updateCartQty = (cartItemId, delta) => {
    setCart(cart.map(item => {
      if (item.cartItemId === cartItemId) {
        const newQty = item.qty + delta;
        return newQty > 0 ? { ...item, qty: newQty } : null;
      }
      return item;
    }).filter(Boolean));
  };

  const updateCartItemNote = (cartItemId, note) => {
    setCart(cart.map(item => item.cartItemId === cartItemId ? { ...item, note } : item));
  };

  const handleOpenBill = () => {
    if (cart.length === 0) return;

    // Buat ID Transaksi
    const idTransaksi = `BILL-${Date.now().toString().slice(-4)}`;

    // 1. Format untuk disimpan ke "Saved Bills" (Draft)
    const bill = {
      id: idTransaksi,
      customerName: customerName || 'Tanpa Nama',
      customerId: activeCustomer?.id || null,
      cart,
      orderType,
      date: new Date()
    };
    setSavedBills([...savedBills, bill]);

    // 2. Format untuk dilempar ke Struk (Receipt Modal)
    const openBillData = {
      id: idTransaksi,
      date: new Date().toISOString(),
      orderType,
      customerName: customerName || 'Tanpa Nama',
      customerId: activeCustomer?.id || null,
      items: cart,
      subtotal: getSubtotal(),
      discount: getDiscount(),
      pointDiscount: getPointDiscount(),
      manualDiscountAmount: getManualDiscountAmount(),
      taxAmount: getTaxAmount(),
      serviceAmount: getServiceChargeAmount(),
      deliveryFee: orderType === 'Delivery' ? deliveryFee : 0,
      total: getTotal(),

      // --- KUNCI PENANDA BELUM LUNAS ---
      status: 'OPEN',
      paymentMethod: 'Belum Bayar'
    };

    // 3. Tampilkan Pop-up Struk!
    setReceiptModal({
      isOpen: true,
      data: openBillData,
      kembalian: 0
    });

    // 4. Reset Cart dan tutup sidebar/modal keranjang
    setCart([]);
    setCustomerName('');
    setSelectedCustomerId(null);
    setAppliedVoucher(null);
    setPointsToRedeem(0);
    setManualDiscount({ type: 'fixed', value: 0 });
    setOrderType('Takeaway');
    setDeliveryFee(0);
    setCustomDeliveryFee('');
    setIsCartOpen(false);
  };

  const loadSavedBill = (bill) => {
    setCart(bill.cart);
    setCustomerName(bill.customerName);
    // Bill lama cuma nyimpen customerName (string), belum ada selectedCustomerId.
    // Coba cocokkan ulang sekali ke customer terdaftar biar poin tetap ke-attach;
    // kalau gak ketemu (nama diketik ulang/beda), biarin null — kasir cukup
    // buka CustomerPickerModal lagi buat resolve manual, gak ada poin yang
    // "ke-klaim diam-diam" ke customer yang salah.
    // Bill baru udah nyimpen customerId langsung (reliable). Bill lama
    // (sebelum fitur ini) cuma punya customerName string — buat itu, coba
    // cocokkan ulang sekali; kalau gak ketemu, biarin null (Guest), gak ada
    // poin yang "ke-klaim diam-diam" ke customer yang salah.
    const matched = bill.customerId
      ? customers.find(c => c.id === bill.customerId)
      : bill.customerName
        ? customers.find(c => c.name.trim().toLowerCase() === bill.customerName.trim().toLowerCase())
        : null;
    setSelectedCustomerId(matched ? matched.id : null);
    setOrderType(bill.orderType);
    setSavedBills(savedBills.filter(b => b.id !== bill.id));
    triggerAlert('Bill berhasil dimuat!');
  };

  const printReceipt = () => window.print();

  // LIVE MATERIALS POOL (RAW + PREP)
  const availableMaterials = useMemo(() => {
    const prepsAsMaterials = semiFinished.map(prep => {
      // 1. Hitung total biaya bahan mentah yang masuk ke Prep berdasarkan harga pasar live
      const totalIngCost = prep.ingredients.reduce((sum, ing) => {
        const rm = rawMaterials.find(r => r.id === ing.rawMaterialId);
        const currentPrice = rm ? rm.price : (ing.snapshotPrice || 0);
        return sum + (currentPrice * ing.qtyUsedFraction);
      }, 0);

      // 2. Tambahkan cost labor & overhead dari Prep
      const totalBatchCost = totalIngCost + (Number(prep.laborCost) || 0) + (Number(prep.overheadCost) || 0);

      // 3. Bagi dengan yield untuk dapat Harga per Satuan
      const costPerUnit = totalBatchCost / Math.max(1, Number(prep.yieldQty) || 1);

      return {
        id: prep.id,
        name: `${prep.name} [Prep]`, // Kasih penanda
        unit: prep.resultUnit,
        price: costPerUnit,
        isPrep: true,
        lastUpdated: prep.lastUpdated || new Date()
      };
    });

    return [...rawMaterials, ...prepsAsMaterials];
  }, [rawMaterials, semiFinished]);

  // Membungkus semua props di Context Value
  const contextValue = {

    // POS / Cart
    getRoundedTotal,
    getRoundingAdjustment,
    isAdminMode,
    cart, setCart,
    updateCartQty,
    updateCartItemNote,
    isCartOpen, setIsCartOpen,
    editingCartItemId,
    setEditingCartItemId,
    updateCartItemVariants,
    menus, setMenus,
    selectedMenuForVariant, setSelectedMenuForVariant,
    variantGroups, setVariantGroups,
    variantCategories, setVariantCategories,
    variantSelectedOptions, setVariantSelectedOptions,
    isSidebarOpen,

    resetDraft,

    vouchers, setVouchers,
    savedBills, setSavedBills,
    storeSettings, setStoreSettings,
    theme, setTheme,
    colorTheme, setColorTheme,

    // Payment / Discount
    appliedVoucher, setAppliedVoucher,
    manualDiscount, setManualDiscount,
    voucherInputCode, setVoucherInputCode,
    getDiscount,
    getManualDiscountAmount,
    getPointDiscount,

    // Order / Checkout
    customerName, setCustomerName,
    selectedCustomerId, setSelectedCustomerId,
    orderType, setOrderType,
    deliveryFee, setDeliveryFee,
    customDeliveryFee, setCustomDeliveryFee,

    // Customer
    activeCustomer,
    customers, setCustomers,
    pointsToRedeem, setPointsToRedeem,

    // Employee / Payroll
    employees, setEmployees,
    employeeDailyRecords, setEmployeeDailyRecords,
    attendanceLog, setAttendanceLog,
    additionCategories, setAdditionCategories,
    deductionCategories, setDeductionCategories,
    payslipModal, setPayslipModal,

    // Inventory / HPP / Materials
    availableMaterials,
    editingRecipe, setEditingRecipe,
    hppLibrary, setHppLibrary,
    rawMaterials, setRawMaterials,
    semiFinished, setSemiFinished,

    // Categories
    categories, setCategories,
    expenseCategories, setExpenseCategories,
    incomeCategories, setIncomeCategories,
    selectedCategory, setSelectedCategory,

    // Finance / History / Report
    claimsHistory, setClaimsHistory,
    expenses, setExpenses,
    incomes, setIncomes,
    reportDateRange, setReportDateRange,
    salesHistory, setSalesHistory,
    shiftHistory, setShiftHistory,

    // Shift
    currentShift, setCurrentShift,

    // UI State
    currentView, setCurrentView, navigate,
    activeTab, setActiveTab,
    activePreset, setActivePreset,
    searchQuery, setSearchQuery,

    paymentModal, setPaymentModal,
    receiptModal, setReceiptModal,
    customAlert, setCustomAlert,
    confirmModal, setConfirmModal,
    isCategoryModalOpen, setIsCategoryModalOpen,

    // Helpers / Calculations
    getSubtotal,
    getTaxableAmount,
    getTaxAmount,
    getServiceChargeAmount,
    getTotal,
    formatRupiah,

    // Actions
    applyDatePreset,
    handleOpenBill,
    loadSavedBill,
    printReceipt,
    triggerAlert,
    triggerConfirm,

    // Sync
    syncStatus, // 'idle' | 'syncing' | 'ready' | 'error'
  };

  const menuItems = [

    { id: 'dompet', icon: Clock, label: 'Dompet Kasir' },
    { id: 'absensi', icon: Fingerprint, label: 'Absensi Karyawan' },
    { id: 'kasir', icon: ShoppingCart, label: 'Kasir Utama' },
    { id: 'riwayat', icon: History, label: 'Riwayat Pesanan' },
    { id: 'pemasukan', icon: TrendingUp, label: 'Pemasukan' },
    { id: 'pengeluaran', icon: TrendingDown, label: 'Pengeluaran' },
    { id: 'laporan', icon: BarChart3, label: 'Laporan & Profit' },
    { id: 'karyawan', icon: Briefcase, label: 'Manajemen Pegawai' },
    { id: 'menu', icon: List, label: 'Manajemen Menu' },
    { id: 'varian', icon: Layers, label: 'Manajemen Varian' },
    { id: 'hpp', icon: Calculator, label: 'Manajemen HPP' },
    { id: 'pelanggan', icon: Users, label: 'Pelanggan & Voucher' },
    { id: 'pengaturan', icon: Settings, label: 'Pengaturan Sistem' },
    { id: 'backup', icon: Download, label: 'Backup & Restore' },
    { id: 'stok', icon: Warehouse, label: 'Stok Opname' },
    { id: 'akun', icon: UserCog, label: 'Manajemen Akun' },

  ];

  const visibleMenus = isAdminMode
    ? menuItems
    : menuItems.filter(item =>
      ['dompet', 'absensi', 'riwayat', 'pengeluaran', 'pemasukan', 'menu', 'varian', 'backup'].includes(item.id)
    );

  useEffect(() => {
    // 1. Buat variabel untuk menyimpan handle listener
    let backListenerHandle = null;

    // 2. Daftarkan listener tombol back hardware (Capacitor/Android)
    const setupListener = async () => {
      backListenerHandle = await CapacitorApp.addListener('backButton', () => {
        // PRIORITAS 1: Tutup Modal Struk
        if (receiptModal.isOpen) {
          setReceiptModal(r => ({ ...r, isOpen: false }));
        }
        // PRIORITAS 2: Tutup Modal Pembayaran
        else if (paymentModal.isOpen) {
          setPaymentModal(p => ({ ...p, isOpen: false }));
        }
        // PRIORITAS 3: Tutup keranjang belanja
        else if (isCartOpen) {
          setIsCartOpen(false);
        }
        // PRIORITAS 4: Tutup sidebar mobile
        else if (isSidebarOpen) {
          setIsSidebarOpen(false);
        }
        // PRIORITAS 5: Navigasi kembali (pop history stack / toast exit)
        else {
          navigateBack();
        }
      });
    };

    // 3. Panggil setup
    setupListener();

    // 4. Cleanup saat unmount atau deps berubah
    return () => {
      if (backListenerHandle) backListenerHandle.remove();
      clearTimeout(exitToastTimerRef.current);
    };
  }, [
    receiptModal.isOpen,
    paymentModal.isOpen,
    isCartOpen,
    isSidebarOpen,
    navigateBack,
  ]);


  // ── Tampilan saat Supabase belum siap (blocking overlay) ────────────────
  if (!allDataLoaded || syncStatus === 'syncing') {
    const isSyncing = syncStatus === 'syncing';
    const appNameLoading = storeSettings?.appName || 'Mamam Kasir';
    const initialLoading = appNameLoading.trim().charAt(0).toUpperCase() || 'M';

    return (
      <div className="fixed inset-0 z-[9999] flex flex-col items-center justify-center bg-slate-100/40 dark:bg-slate-950/60 backdrop-blur-xl transition-all p-4 overflow-hidden">

        <style dangerouslySetInnerHTML={{
          __html: `
          @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@600;700;800&family=Inter:wght@400;500&display=swap');
          .font-heading { font-family: 'Plus Jakarta Sans', sans-serif; }
          .font-body    { font-family: 'Inter', sans-serif; }
          @keyframes loadbar {
            0%   { transform: translateX(-100%); }
            50%  { transform: translateX(20%); }
            100% { transform: translateX(120%); }
          }
          @keyframes floatGlow {
            0%, 100% { transform: translate(0, 0) scale(1); }
            50%      { transform: translate(10px, -14px) scale(1.06); }
          }
          .loadbar-fill { animation: loadbar 1.8s cubic-bezier(0.4,0,0.2,1) infinite; }
          .glow-orb { animation: floatGlow 6s ease-in-out infinite; }
        `
        }} />

        {/* Ambient glow orbs di background */}
        <div className="absolute -top-24 -left-16 w-72 h-72 bg-accent-300/20 dark:bg-accent-600/10 rounded-full blur-3xl glow-orb pointer-events-none" />
        <div className="absolute -bottom-24 -right-16 w-72 h-72 bg-accent-400/20 dark:bg-accent-500/10 rounded-full blur-3xl glow-orb pointer-events-none" style={{ animationDelay: '2s' }} />

        <div className="relative bg-white/70 dark:bg-slate-900/70 backdrop-blur-2xl p-9 rounded-[2.5rem] shadow-[0_8px_40px_rgb(0,0,0,0.06)] dark:shadow-[0_8px_40px_rgb(0,0,0,0.4)] border border-white/60 dark:border-slate-800/60 flex flex-col items-center max-w-sm w-full mx-4 animate-in fade-in zoom-in-95 duration-700 ease-out">

          {/* Logo mark + Loader cincin */}
          <div className="relative flex items-center justify-center w-24 h-24 mb-7">
            {/* Lingkaran statis tipis */}
            <div className="absolute inset-0 rounded-full border-[1px] border-slate-200 dark:border-slate-700/50"></div>

            {/* Lingkaran berputar elegan */}
            <div className="absolute inset-0 rounded-full border-[2px] border-accent-500 border-r-transparent border-b-transparent animate-[spin_1.5s_cubic-bezier(0.4,0,0.2,1)_infinite]"></div>
            <div className="absolute inset-[6px] rounded-full border-[1.5px] border-accent-300 dark:border-accent-700 border-l-transparent border-t-transparent animate-[spin_2s_cubic-bezier(0.4,0,0.2,1)_infinite_reverse]"></div>

            {/* Logo mark di tengah */}
            <div className="w-14 h-14 rounded-[1.25rem] bg-gradient-to-br from-accent-500 to-accent-600 dark:from-accent-400 dark:to-accent-600 flex items-center justify-center shadow-[0_4px_18px_rgba(var(--color-accent-500),0.4)]">
              <span className="font-heading font-black text-2xl text-white">{initialLoading}</span>
            </div>
          </div>

          {/* Tipografi Bersih */}
          <div className="text-center space-y-1.5 mb-2">
            <h1 className="font-heading text-2xl font-extrabold bg-clip-text text-transparent bg-gradient-to-r from-slate-900 to-slate-500 dark:from-white dark:to-slate-400 tracking-tight">
              {appNameLoading}
            </h1>
            <p className="font-body text-sm font-medium text-slate-400 dark:text-slate-500">
              {isSyncing ? 'Menyinkronkan ekosistem...' : 'Menyiapkan ruang kerjamu...'}
            </p>
          </div>

          {/* Indikator Progress Casual */}
          <div className="mt-6 flex flex-col items-center gap-3 w-full">
            {syncStep && (
              <p className="font-body text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-[0.15em] text-center animate-pulse">
                {syncStep}
              </p>
            )}
            <div className="w-40 h-[3px] bg-slate-200 dark:bg-slate-800 rounded-full overflow-hidden">
              <div className="h-full w-1/3 bg-gradient-to-r from-accent-400 via-accent-500 to-accent-400 rounded-full loadbar-fill"></div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <AppContext.Provider value={contextValue}>

      <style dangerouslySetInnerHTML={{
        __html: `
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');
        .font-heading { font-family: 'Plus Jakarta Sans', sans-serif; }
        .font-body { font-family: 'Inter', sans-serif; }
        .custom-scrollbar::-webkit-scrollbar { width: 4px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 10px; }
        .custom-scrollbar:hover::-webkit-scrollbar-thumb { background: #94a3b8; }
      `
      }} />

      <AppLayout
        isSidebarOpen={isSidebarOpen}
        onSwipeOpen={() => setIsSidebarOpen(true)}
        onSwipeClose={() => setIsSidebarOpen(false)}
        sidebar={
          <Sidebar
            currentView={currentView}
            setCurrentView={setCurrentView}
            isSidebarOpen={isSidebarOpen}
            setIsSidebarOpen={setIsSidebarOpen}
            visibleMenus={visibleMenus}
            isAdminMode={isAdminMode}
            setShowPinModal={setShowPinModal}
            triggerConfirm={triggerConfirm}
            setIsAdminMode={setIsAdminMode}
          />
        }
        header={
          <Header
            currentView={currentView}
            currentShift={currentShift}
            setIsSidebarOpen={setIsSidebarOpen}
            today={today}
          />
        }
        content={
          <AppRoutes currentView={currentView} />
        }
        bottomNav={
          <BottomNav
            currentView={currentView}
            navigate={navigate}
          />
        }
        overlays={
          <>
            {/* Toast "Ketuk sekali lagi untuk keluar" */}
            {showExitToast && (
              <div className="absolute bottom-10 left-1/2 -translate-x-1/2 z-[200] pointer-events-none exit-toast animate-in fade-in slide-in-from-bottom-4 duration-300">
                <div className="flex items-center gap-2 bg-accent-600/95 dark:bg-accent-500/95 text-white text-sm font-semibold px-5 py-3 rounded-full shadow-2xl backdrop-blur-sm border border-white/20 dark:border-orange-400/30 whitespace-nowrap">
                  <span>Ketuk sekali lagi untuk keluar</span>
                </div>
              </div>
            )}

            {/* Badge status koneksi — pojok kanan atas, nempel selama offline */}
            {!isOnline && (
              <div
                className="fixed right-4 z-[190] animate-in fade-in slide-in-from-top-3 duration-300"
                style={{ top: 'calc(env(safe-area-inset-top, 0px) + 1rem)' }}
              >
                <div className="flex items-center gap-1.5 bg-slate-800/95 dark:bg-slate-900/95 text-slate-100 text-[11px] font-semibold pl-2.5 pr-3 py-1.5 rounded-full shadow-lg backdrop-blur-sm border border-white/10 whitespace-nowrap">
                  <span className="relative flex h-2 w-2">
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-slate-400"></span>
                  </span>
                  <WifiOff className="w-3.5 h-3.5 shrink-0" />
                  <span>Offline</span>
                </div>
              </div>
            )}

            {/* Toast koneksi online/offline */}
            {connectionToast && (
              <div
                className="fixed left-1/2 -translate-x-1/2 z-[200] pointer-events-none animate-in fade-in slide-in-from-top-4 duration-300"
                style={{ top: 'calc(env(safe-area-inset-top, 0px) + 1rem)' }}
              >
                <div className={`flex items-center gap-2 text-white text-sm font-semibold px-5 py-3 rounded-full shadow-2xl backdrop-blur-sm border whitespace-nowrap
                  ${connectionToast.type === 'offline'
                    ? 'bg-slate-700/95 dark:bg-slate-800/95 border-white/20'
                    : connectionToast.type === 'syncing'
                      ? 'bg-indigo-600/95 border-white/20'
                      : 'bg-emerald-600/95 border-white/20'}`}>
                  {connectionToast.type === 'offline' ? (
                    <WifiOff className="w-4 h-4 shrink-0" />
                  ) : connectionToast.type === 'syncing' ? (
                    <RefreshCw className="w-4 h-4 shrink-0 animate-spin" />
                  ) : (
                    <Wifi className="w-4 h-4 shrink-0" />
                  )}
                  <span>{connectionToast.msg}</span>
                </div>
              </div>
            )}

            {/* Overlay backdrop sidebar mobile */}
            {isSidebarOpen && (
              <div
                className="fixed inset-0 bg-slate-500/30 dark:bg-slate-800/40 z-40 md:hidden backdrop-blur-sm transition-opacity duration-300"
                onClick={() => setIsSidebarOpen(false)}
              />
            )}

            {/* Alert modal */}
            <Modal
              isOpen={customAlert.isOpen}
              onClose={() => setCustomAlert({ isOpen: false, message: '' })}
              zLevel="top"
              size="sm"
              className="p-6 text-center"
            >
              <div className="w-12 h-12 bg-green-50 dark:bg-green-500/10 text-green-500 dark:text-green-400 rounded-full flex items-center justify-center mx-auto mb-4 animate-in zoom-in">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <h3 className="font-heading font-bold text-slate-900 dark:text-slate-50 text-lg mb-2">Pemberitahuan</h3>
              <p className="text-slate-500 dark:text-slate-400 text-sm mb-6">{customAlert.message}</p>
              <Button
                size="full"
                onClick={() => setCustomAlert({ isOpen: false, message: '' })}
              >
                Tutup
              </Button>
            </Modal>

            {/* Confirm modal */}
            <Modal
              isOpen={confirmModal.isOpen}
              onClose={() => setConfirmModal({ isOpen: false, message: '', onConfirm: null })}
              closeOnBackdrop={false}
              zLevel="top"
              size="sm"
              className="p-6 text-center"
            >
              <div className="w-12 h-12 bg-accent-50 dark:bg-accent-500/10 text-accent-600 dark:text-accent-400 rounded-full flex items-center justify-center mx-auto mb-4 animate-in zoom-in">
                <AlertCircle className="w-6 h-6" />
              </div>
              <h3 className="font-heading font-bold text-slate-900 dark:text-slate-50 text-lg mb-2">Konfirmasi Tindakan</h3>
              <p className="text-slate-500 dark:text-slate-400 text-sm mb-6 leading-relaxed">{confirmModal.message}</p>
              <div className="flex gap-3">
                <Button
                  variant="secondary"
                  size="lg"
                  className="flex-1"
                  onClick={() => setConfirmModal({ isOpen: false, message: '', onConfirm: null })}
                >
                  Batal
                </Button>
                <Button
                  variant="danger"
                  size="lg"
                  className="flex-1"
                  onClick={() => {
                    if (confirmModal.onConfirm) confirmModal.onConfirm();
                    setConfirmModal({ isOpen: false, message: '', onConfirm: null });
                  }}
                >
                  Ya
                </Button>
              </div>
            </Modal>

            {/* PIN Modal */}
            <PinModal
              isOpen={showPinModal}
              onClose={() => setShowPinModal(false)}
              onSuccess={() => {
                setIsAdminMode(true);
                setShowPinModal(false);
              }}
              triggerAlert={triggerAlert}
            />

            <ReceiptModal />
          </>
        }
      />

    </AppContext.Provider>
  );
}

function SyncStatusBadge({ status }) {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (status === 'ready') {
      setVisible(true);
      const t = setTimeout(() => setVisible(false), 3000);
      return () => clearTimeout(t);
    }
    if (status === 'error') {
      setVisible(true);
    }
  }, [status]);

  if (status === 'idle' || !visible) return null;

  const cfg = status === 'ready'
    ? { bg: 'bg-emerald-500', text: 'Tersinkronisasi ✓' }
    : { bg: 'bg-accent-500', text: 'Sync gagal — data lokal' };

  return (
    <div
      className={`fixed bottom-4 right-4 z-50 px-3 py-1.5 rounded-full text-white text-xs font-medium shadow-lg transition-opacity duration-500 ${cfg.bg}`}
      style={{ fontFamily: 'Inter, sans-serif' }}
    >
      {cfg.text}
    </div>
  );
}